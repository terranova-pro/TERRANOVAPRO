-- Create public bucket for property images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'property-images',
  'property-images',
  true,
  10485760,  -- 10 MB per file
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Public read
CREATE POLICY "property_images_public_select"
  ON storage.objects FOR SELECT TO anon
  USING (bucket_id = 'property-images');

-- Authenticated upload
CREATE POLICY "property_images_auth_insert"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'property-images');

-- Authenticated update
CREATE POLICY "property_images_auth_update"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'property-images');

-- Authenticated delete
CREATE POLICY "property_images_auth_delete"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'property-images');
