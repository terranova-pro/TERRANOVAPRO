-- ── 1. Revoke EXECUTE on handle_new_user from PUBLIC (covers anon + authenticated) ──
-- Prior migration only revoked from named roles; PUBLIC still grants it.
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC;


-- ── 2. Narrow submissions_public_insert so WITH CHECK is not always true ─────────
-- Validates that the three required contact fields are actually non-empty strings.
-- This keeps the public contact-form flow working while satisfying RLS requirements.
DROP POLICY IF EXISTS "submissions_public_insert" ON public.property_submissions;

CREATE POLICY "submissions_public_insert" ON public.property_submissions
  FOR INSERT TO anon
  WITH CHECK (
    owner_name  IS NOT NULL AND char_length(trim(owner_name))  > 0 AND
    owner_email IS NOT NULL AND char_length(trim(owner_email)) > 0 AND
    owner_phone IS NOT NULL AND char_length(trim(owner_phone)) > 0
  );


-- ── 3. Remove the broad authenticated SELECT on storage.objects ───────────────
-- The bucket is public = true, so direct object URLs remain accessible without
-- any storage.objects RLS policy. Removing the SELECT policy prevents API-level
-- directory listing without breaking URL-based image access.
DROP POLICY IF EXISTS "property_images_auth_select" ON storage.objects;
