-- ── 1. Fix handle_new_user: set immutable search_path ─────────────────────────
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'role', 'agente')
  );
  RETURN NEW;
END;
$$;

-- Revoke direct RPC execution from public roles (it's a trigger, not an API endpoint)
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;


-- ── 2. Fix properties write policies ──────────────────────────────────────────
-- Any active staff can insert/update; only admin/fundador can delete
DROP POLICY IF EXISTS "properties_auth_insert" ON public.properties;
DROP POLICY IF EXISTS "properties_auth_update" ON public.properties;
DROP POLICY IF EXISTS "properties_auth_delete" ON public.properties;

CREATE POLICY "properties_auth_insert" ON public.properties
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );

CREATE POLICY "properties_auth_update" ON public.properties
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );

CREATE POLICY "properties_auth_delete" ON public.properties
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  );


-- ── 3. Fix blog_posts write policies ─────────────────────────────────────────
-- Only admin/fundador can manage blog content
DROP POLICY IF EXISTS "blog_auth_insert" ON public.blog_posts;
DROP POLICY IF EXISTS "blog_auth_update" ON public.blog_posts;
DROP POLICY IF EXISTS "blog_auth_delete" ON public.blog_posts;

CREATE POLICY "blog_auth_insert" ON public.blog_posts
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  );

CREATE POLICY "blog_auth_update" ON public.blog_posts
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  );

CREATE POLICY "blog_auth_delete" ON public.blog_posts
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  );


-- ── 4. Fix contacts write policies ───────────────────────────────────────────
-- Any active staff can insert/update; only admin/fundador can delete
DROP POLICY IF EXISTS "contacts_auth_insert" ON public.contacts;
DROP POLICY IF EXISTS "contacts_auth_update" ON public.contacts;
DROP POLICY IF EXISTS "contacts_auth_delete" ON public.contacts;

CREATE POLICY "contacts_auth_insert" ON public.contacts
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );

CREATE POLICY "contacts_auth_update" ON public.contacts
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );

CREATE POLICY "contacts_auth_delete" ON public.contacts
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  );


-- ── 5. Fix management_contracts write policies ────────────────────────────────
DROP POLICY IF EXISTS "mgmt_auth_insert" ON public.management_contracts;
DROP POLICY IF EXISTS "mgmt_auth_update" ON public.management_contracts;
DROP POLICY IF EXISTS "mgmt_auth_delete" ON public.management_contracts;

CREATE POLICY "mgmt_auth_insert" ON public.management_contracts
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );

CREATE POLICY "mgmt_auth_update" ON public.management_contracts
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );

CREATE POLICY "mgmt_auth_delete" ON public.management_contracts
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
        AND role IN ('fundador', 'admin')
    )
  );


-- ── 6. Fix property_submissions policies ─────────────────────────────────────
-- anon INSERT kept intentionally for public contact forms, but tighten UPDATE
DROP POLICY IF EXISTS "submissions_public_insert" ON public.property_submissions;
DROP POLICY IF EXISTS "submissions_auth_update" ON public.property_submissions;

-- Public contact-form submit: allow anon inserts (intended behavior)
CREATE POLICY "submissions_public_insert" ON public.property_submissions
  FOR INSERT TO anon
  WITH CHECK (true);

-- Only active staff can update submissions
CREATE POLICY "submissions_auth_update" ON public.property_submissions
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_active = true
    )
  );


-- ── 7. Fix storage: remove broad anon listing on property-images ──────────────
-- Direct public URLs still work because the bucket is public = true.
-- Removing the SELECT policy only prevents API listing by anonymous clients.
DROP POLICY IF EXISTS "property_images_public_select" ON storage.objects;

-- Authenticated staff can list/read objects in the bucket
CREATE POLICY "property_images_auth_select" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'property-images');
