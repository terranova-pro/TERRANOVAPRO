-- Fix handle_new_user trigger to use new role names
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.email,
    CASE
      WHEN NEW.raw_user_meta_data->>'role' IN ('fundador','administrador','ejecutivo')
        THEN NEW.raw_user_meta_data->>'role'
      ELSE 'ejecutivo'
    END
  );
  RETURN NEW;
END;
$$;
