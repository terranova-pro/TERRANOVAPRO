-- Properties table
CREATE TABLE properties (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  property_type TEXT NOT NULL CHECK (property_type IN ('departamento', 'casa', 'terreno', 'oficina', 'comercial', 'bodega', 'estacionamiento', 'agricola')),
  listing_type TEXT NOT NULL CHECK (listing_type IN ('venta', 'arriendo', 'arriendo_diario', 'arriendo_temporada')),
  price INTEGER,
  price_uf NUMERIC,
  currency TEXT DEFAULT 'CLP' CHECK (currency IN ('CLP', 'UF')),
  region TEXT NOT NULL,
  comuna TEXT NOT NULL,
  address TEXT,
  latitude NUMERIC,
  longitude NUMERIC,
  m2_util NUMERIC,
  m2_terreno NUMERIC,
  dormitorios INTEGER,
  banos INTEGER,
  estacionamientos INTEGER DEFAULT 0,
  year_built INTEGER,
  featured BOOLEAN DEFAULT false,
  status TEXT DEFAULT 'disponible' CHECK (status IN ('disponible', 'reservada', 'vendida', 'arrendada')),
  images TEXT[] DEFAULT '{}',
  video_url TEXT,
  portal_ids JSONB DEFAULT '{}',
  owner_name TEXT,
  owner_phone TEXT,
  owner_email TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Contacts/CRM table
CREATE TABLE contacts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  source TEXT DEFAULT 'web' CHECK (source IN ('web', 'whatsapp', 'portal', 'referral', 'walk_in')),
  type TEXT DEFAULT 'buyer' CHECK (type IN ('buyer', 'seller', 'tenant', 'landlord', 'investor')),
  interest TEXT,
  property_id UUID REFERENCES properties(id),
  notes TEXT,
  status TEXT DEFAULT 'nuevo' CHECK (status IN ('nuevo', 'contactado', 'calificado', 'propuesta', 'negociacion', 'cerrado', 'perdido')),
  budget_min INTEGER,
  budget_max INTEGER,
  preferred_regions TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Property submissions
CREATE TABLE property_submissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_name TEXT NOT NULL,
  owner_email TEXT NOT NULL,
  owner_phone TEXT NOT NULL,
  owner_rut TEXT,
  property_type TEXT NOT NULL,
  listing_type TEXT DEFAULT 'venta',
  address TEXT NOT NULL,
  region TEXT NOT NULL,
  comuna TEXT NOT NULL,
  m2_util NUMERIC,
  m2_terreno NUMERIC,
  dormitorios INTEGER,
  banos INTEGER,
  estacionamientos INTEGER DEFAULT 0,
  asking_price NUMERIC,
  description TEXT,
  has_title BOOLEAN DEFAULT false,
  has_plan BOOLEAN DEFAULT false,
  has_permits BOOLEAN DEFAULT false,
  status TEXT DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'en_revision', 'aprobada', 'rechazada', 'publicada')),
  is_terreno BOOLEAN DEFAULT false,
  terrain_type TEXT CHECK (terrain_type IN ('urbano', 'rural', 'agricola', 'industrial', 'residencial')),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Blog posts
CREATE TABLE blog_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  excerpt TEXT,
  content TEXT NOT NULL,
  image_url TEXT,
  category TEXT DEFAULT 'noticias' CHECK (category IN ('noticias', 'consejos', 'mercado', 'inversiones', 'legislacion')),
  published BOOLEAN DEFAULT false,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Property management contracts
CREATE TABLE management_contracts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  property_id UUID REFERENCES properties(id),
  owner_name TEXT NOT NULL,
  owner_email TEXT NOT NULL,
  owner_phone TEXT NOT NULL,
  monthly_rent INTEGER,
  commission_pct NUMERIC DEFAULT 10,
  start_date DATE,
  end_date DATE,
  status TEXT DEFAULT 'activo' CHECK (status IN ('activo', 'finalizado', 'suspendido')),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE property_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE management_contracts ENABLE ROW LEVEL SECURITY;

-- Properties: public read, authenticated write
CREATE POLICY "properties_public_select" ON properties FOR SELECT TO anon USING (true);
CREATE POLICY "properties_auth_insert" ON properties FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "properties_auth_update" ON properties FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "properties_auth_delete" ON properties FOR DELETE TO authenticated USING (true);

-- Contacts: authenticated only
CREATE POLICY "contacts_auth_select" ON contacts FOR SELECT TO authenticated USING (true);
CREATE POLICY "contacts_auth_insert" ON contacts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "contacts_auth_update" ON contacts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "contacts_auth_delete" ON contacts FOR DELETE TO authenticated USING (true);

-- Submissions: public insert, authenticated read/write
CREATE POLICY "submissions_public_insert" ON property_submissions FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "submissions_auth_select" ON property_submissions FOR SELECT TO authenticated USING (true);
CREATE POLICY "submissions_auth_update" ON property_submissions FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- Blog: public read, authenticated write
CREATE POLICY "blog_public_select" ON blog_posts FOR SELECT TO anon USING (true);
CREATE POLICY "blog_auth_insert" ON blog_posts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "blog_auth_update" ON blog_posts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "blog_auth_delete" ON blog_posts FOR DELETE TO authenticated USING (true);

-- Management: authenticated only
CREATE POLICY "mgmt_auth_select" ON management_contracts FOR SELECT TO authenticated USING (true);
CREATE POLICY "mgmt_auth_insert" ON management_contracts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "mgmt_auth_update" ON management_contracts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "mgmt_auth_delete" ON management_contracts FOR DELETE TO authenticated USING (true);

-- Indexes
CREATE INDEX idx_properties_region ON properties(region);
CREATE INDEX idx_properties_comuna ON properties(comuna);
CREATE INDEX idx_properties_type ON properties(property_type);
CREATE INDEX idx_properties_listing ON properties(listing_type);
CREATE INDEX idx_properties_price ON properties(price);
CREATE INDEX idx_properties_featured ON properties(featured) WHERE featured = true;
CREATE INDEX idx_contacts_status ON contacts(status);
CREATE INDEX idx_submissions_status ON property_submissions(status);
CREATE INDEX idx_blog_slug ON blog_posts(slug);
CREATE INDEX idx_blog_published ON blog_posts(published) WHERE published = true;