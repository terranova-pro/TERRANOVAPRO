-- Update role check constraint to use new role names
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
ALTER TABLE profiles ADD CONSTRAINT profiles_role_check
  CHECK (role IN ('fundador', 'administrador', 'ejecutivo'));

-- Migrate existing roles
UPDATE profiles SET role = 'administrador' WHERE role = 'admin';
UPDATE profiles SET role = 'ejecutivo' WHERE role IN ('agente', 'soporte');

-- Update RLS policies to use new role names
DROP POLICY IF EXISTS "Fundador can manage all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can read all profiles" ON profiles;

CREATE POLICY "Fundador can manage all profiles" ON profiles
  FOR ALL TO authenticated
  USING (
    auth.uid() = id OR
    EXISTS (
      SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'fundador'
    )
  )
  WITH CHECK (
    auth.uid() = id OR
    EXISTS (
      SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'fundador'
    )
  );

CREATE POLICY "Administrador can read all profiles" ON profiles
  FOR SELECT TO authenticated
  USING (
    auth.uid() = id OR
    EXISTS (
      SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('fundador', 'administrador')
    )
  );
