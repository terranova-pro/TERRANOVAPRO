import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import type { Contact, PropertySubmission } from '../types'
import { Users, FileText, Clock, Eye } from 'lucide-react'

const STATUS_LABELS: Record<string, string> = {
  nuevo: 'Nuevo', contactado: 'Contactado', calificado: 'Calificado',
  propuesta: 'Propuesta', negociacion: 'Negociación', cerrado: 'Cerrado', perdido: 'Perdido',
}
const STATUS_COLORS: Record<string, string> = {
  nuevo: 'bg-blue-900/40 text-blue-400', contactado: 'bg-amber-900/40 text-amber-400',
  calificado: 'bg-emerald-900/40 text-emerald-400', propuesta: 'bg-violet-900/40 text-violet-400',
  negociacion: 'bg-orange-900/40 text-orange-400', cerrado: 'bg-green-900/40 text-green-400',
  perdido: 'bg-red-900/40 text-red-400',
}

const SUB_STATUS_LABELS: Record<string, string> = {
  pendiente: 'Pendiente', en_revision: 'En Revisión', aprobada: 'Aprobada',
  rechazada: 'Rechazada', publicada: 'Publicada',
}
const SUB_STATUS_COLORS: Record<string, string> = {
  pendiente: 'bg-amber-900/40 text-amber-400', en_revision: 'bg-blue-900/40 text-blue-400',
  aprobada: 'bg-green-900/40 text-green-400', rechazada: 'bg-red-900/40 text-red-400',
  publicada: 'bg-emerald-900/40 text-emerald-400',
}

export default function CRM() {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [submissions, setSubmissions] = useState<PropertySubmission[]>([])
  const [tab, setTab] = useState<'contacts' | 'submissions'>('contacts')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    const [contactsRes, submissionsRes] = await Promise.all([
      supabase.from('contacts').select('*').order('created_at', { ascending: false }).limit(50),
      supabase.from('property_submissions').select('*').order('created_at', { ascending: false }).limit(50),
    ])
    setContacts(contactsRes.data || [])
    setSubmissions(submissionsRes.data || [])
    setLoading(false)
  }

  const totalContacts = contacts.length
  const newContacts = contacts.filter((c) => c.status === 'nuevo').length
  const totalSubmissions = submissions.length
  const pendingSubmissions = submissions.filter((s) => s.status === 'pendiente').length

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-10 border-b border-gold/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-heading text-3xl font-bold text-white">
            <span className="text-gold">CRM</span> Dashboard
          </h1>
          <p className="mt-2 text-neutral-500 text-sm">Gestión de contactos y solicitudes de propiedades</p>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { icon: Users, label: 'Total contactos', value: totalContacts },
              { icon: Eye, label: 'Nuevos', value: newContacts },
              { icon: FileText, label: 'Solicitudes', value: totalSubmissions },
              { icon: Clock, label: 'Pendientes', value: pendingSubmissions },
            ].map((s) => (
              <div key={s.label} className="bg-[#191919] rounded-xl p-4 border border-gold/10">
                <div className="flex items-center gap-3">
                  <s.icon className="w-8 h-8 text-gold" />
                  <div>
                    <div className="text-2xl font-bold text-white">{s.value}</div>
                    <div className="text-xs text-neutral-500">{s.label}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-[#191919] rounded-lg border border-gold/15 p-0.5 w-fit mb-6">
            <button
              onClick={() => setTab('contacts')}
              className={`px-4 py-2 rounded text-sm font-medium transition-colors ${tab === 'contacts' ? 'bg-gold text-black-brand' : 'text-neutral-500 hover:text-neutral-300'}`}
            >
              Contactos ({totalContacts})
            </button>
            <button
              onClick={() => setTab('submissions')}
              className={`px-4 py-2 rounded text-sm font-medium transition-colors ${tab === 'submissions' ? 'bg-gold text-black-brand' : 'text-neutral-500 hover:text-neutral-300'}`}
            >
              Solicitudes ({totalSubmissions})
            </button>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-[#191919] rounded-lg p-4 animate-shimmer h-16" />
              ))}
            </div>
          ) : tab === 'contacts' ? (
            <div className="bg-[#191919] rounded-xl border border-gold/10 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-[#141414] border-b border-gold/10">
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Nombre</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Email</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Teléfono</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Tipo</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Estado</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contacts.map((c) => (
                      <tr key={c.id} className="border-b border-gold/5 hover:bg-[#1c1c1c]">
                        <td className="px-4 py-3 font-medium text-white">{c.name}</td>
                        <td className="px-4 py-3 text-neutral-400">{c.email || '-'}</td>
                        <td className="px-4 py-3 text-neutral-400">{c.phone || '-'}</td>
                        <td className="px-4 py-3 capitalize text-neutral-400">{c.type}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[c.status] || 'bg-neutral-800 text-neutral-400'}`}>
                            {STATUS_LABELS[c.status]}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-neutral-500">{new Date(c.created_at).toLocaleDateString('es-CL')}</td>
                      </tr>
                    ))}
                    {contacts.length === 0 && (
                      <tr><td colSpan={6} className="px-4 py-8 text-center text-neutral-500">No hay contactos registrados</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="bg-[#191919] rounded-xl border border-gold/10 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-[#141414] border-b border-gold/10">
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Propietario</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Tipo</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Región</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Comuna</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Estado</th>
                      <th className="text-left px-4 py-3 font-medium text-neutral-500">Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    {submissions.map((s) => (
                      <tr key={s.id} className="border-b border-gold/5 hover:bg-[#1c1c1c]">
                        <td className="px-4 py-3">
                          <div className="font-medium text-white">{s.owner_name}</div>
                          <div className="text-xs text-neutral-500">{s.owner_email}</div>
                        </td>
                        <td className="px-4 py-3 text-neutral-400 capitalize">
                          {s.is_terreno ? 'Terreno' : s.property_type}
                        </td>
                        <td className="px-4 py-3 text-neutral-400">{s.region}</td>
                        <td className="px-4 py-3 text-neutral-400">{s.comuna}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${SUB_STATUS_COLORS[s.status] || 'bg-neutral-800 text-neutral-400'}`}>
                            {SUB_STATUS_LABELS[s.status]}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-neutral-500">{new Date(s.created_at).toLocaleDateString('es-CL')}</td>
                      </tr>
                    ))}
                    {submissions.length === 0 && (
                      <tr><td colSpan={6} className="px-4 py-8 text-center text-neutral-500">No hay solicitudes registradas</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
