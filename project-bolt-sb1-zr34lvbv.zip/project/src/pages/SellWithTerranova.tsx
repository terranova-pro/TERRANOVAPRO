import { useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle, Upload, ArrowRight } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { PROPERTY_TYPES, REGIONS, COMUNAS_BY_REGION } from '../data/chile'
import SectionHeading from '../components/SectionHeading'

export default function SellWithTerranova() {
  const [form, setForm] = useState({
    owner_name: '', owner_email: '', owner_phone: '', owner_rut: '',
    property_type: '', address: '', region: '', comuna: '',
    m2_util: '', m2_terreno: '', dormitorios: '', banos: '', estacionamientos: '0',
    asking_price: '', description: '',
    has_title: false, has_plan: false, has_permits: false,
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const comunas = form.region ? COMUNAS_BY_REGION[form.region] || [] : []

  function update(key: string, value: string | boolean) {
    const next = { ...form, [key]: value }
    if (key === 'region') next.comuna = ''
    setForm(next)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await supabase.from('property_submissions').insert({
      owner_name: form.owner_name,
      owner_email: form.owner_email,
      owner_phone: form.owner_phone,
      owner_rut: form.owner_rut || null,
      property_type: form.property_type,
      listing_type: 'venta',
      address: form.address,
      region: form.region,
      comuna: form.comuna,
      m2_util: form.m2_util ? Number(form.m2_util) : null,
      m2_terreno: form.m2_terreno ? Number(form.m2_terreno) : null,
      dormitorios: form.dormitorios ? Number(form.dormitorios) : null,
      banos: form.banos ? Number(form.banos) : null,
      estacionamientos: Number(form.estacionamientos),
      asking_price: form.asking_price ? Number(form.asking_price) : null,
      description: form.description || null,
      has_title: form.has_title,
      has_plan: form.has_plan,
      has_permits: form.has_permits,
      is_terreno: false,
      status: 'pendiente',
    })
    setSubmitted(true)
    setLoading(false)
  }

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-4xl sm:text-5xl font-bold text-white">
            Vende con <span className="text-gold">Terranova</span>
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Publicamos tu propiedad en los principales portales inmobiliarios de Chile con un solo registro.
          </p>
        </div>
      </section>

      <section className="py-24 bg-[#141414]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Benefits */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mb-16">
            {[
              { title: 'Publicación Multi-Portal', desc: 'Tu propiedad aparece en Portal Inmobiliario, Yapo y Propiedades Chile simultáneamente.' },
              { title: 'Fotografía Profesional', desc: 'Sesión fotográfica incluida para destacar tu propiedad sobre el promedio.' },
              { title: 'Asesoría Legal', desc: 'Te acompañamos en todo el proceso de escrituración y cierre.' },
            ].map((b) => (
              <div key={b.title} className="bg-[#191919] p-8 rounded-xl border border-gold/10">
                <CheckCircle className="w-8 h-8 text-gold mb-4" />
                <h3 className="font-heading text-xl font-semibold text-white">{b.title}</h3>
                <p className="mt-3 text-sm text-neutral-500 leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>

          {/* Process */}
          <SectionHeading title="Proceso de venta" subtitle="3 pasos simples para vender tu propiedad" center />
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            {[
              { step: '1', label: 'Completa el formulario' },
              { step: '2', label: 'Evaluación y fotografía' },
              { step: '3', label: 'Publicación y gestión' },
            ].map((s, i) => (
              <div key={s.step} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gold text-black-brand rounded-full flex items-center justify-center font-bold text-sm">{s.step}</div>
                <span className="text-sm font-medium text-neutral-300">{s.label}</span>
                {i < 2 && <ArrowRight className="w-5 h-5 text-gold hidden sm:block" />}
              </div>
            ))}
          </div>

          {/* Form */}
          {submitted ? (
            <div className="text-center py-16 bg-[#191919] rounded-2xl border border-gold/15">
              <CheckCircle className="w-16 h-16 text-gold mx-auto mb-4" />
              <h3 className="font-heading text-2xl font-bold text-white">Solicitud recibida</h3>
              <p className="mt-3 text-neutral-500 max-w-md mx-auto leading-relaxed">
                Nuestro equipo revisará tu propiedad y se contactará contigo en las próximas 24 horas para iniciar el proceso.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-[#191919] rounded-2xl p-6 sm:p-8 border border-gold/10">
              <h3 className="font-heading text-xl font-semibold text-white mb-6">Datos del propietario</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                <input required placeholder="Nombre completo" value={form.owner_name} onChange={(e) => update('owner_name', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input required type="email" placeholder="Email" value={form.owner_email} onChange={(e) => update('owner_email', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input required placeholder="Teléfono" value={form.owner_phone} onChange={(e) => update('owner_phone', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input placeholder="RUT" value={form.owner_rut} onChange={(e) => update('owner_rut', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
              </div>

              <h3 className="font-heading text-xl font-semibold text-black-brand mb-6">Datos de la propiedad</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <select required value={form.property_type} onChange={(e) => update('property_type', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 focus:outline-none focus:border-gold/50 appearance-none">
                  <option value="">Tipo de inmueble</option>
                  {PROPERTY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
                <select required value={form.region} onChange={(e) => update('region', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 focus:outline-none focus:border-gold/50 appearance-none">
                  <option value="">Región</option>
                  {REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
                <select required value={form.comuna} onChange={(e) => update('comuna', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 focus:outline-none focus:border-gold/50 appearance-none" disabled={!comunas.length}>
                  <option value="">Comuna</option>
                  {comunas.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <input required placeholder="Dirección" value={form.address} onChange={(e) => update('address', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 sm:col-span-2" />
                <input type="number" placeholder="Precio solicitado (CLP)" value={form.asking_price} onChange={(e) => update('asking_price', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input type="number" placeholder="m² útiles" value={form.m2_util} onChange={(e) => update('m2_util', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input type="number" placeholder="m² terreno" value={form.m2_terreno} onChange={(e) => update('m2_terreno', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input type="number" placeholder="Dormitorios" value={form.dormitorios} onChange={(e) => update('dormitorios', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input type="number" placeholder="Baños" value={form.banos} onChange={(e) => update('banos', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                <input type="number" placeholder="Estacionamientos" value={form.estacionamientos} onChange={(e) => update('estacionamientos', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
              </div>

              <textarea placeholder="Descripción de la propiedad" rows={4} value={form.description} onChange={(e) => update('description', e.target.value)} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 resize-none mb-6" />

              <div className="flex flex-wrap gap-6 mb-8">
                {[
                  { key: 'has_title', label: 'Tiene escritura' },
                  { key: 'has_plan', label: 'Tiene planos' },
                  { key: 'has_permits', label: 'Tiene permisos municipales' },
                ].map((c) => (
                  <label key={c.key} className="flex items-center gap-2 cursor-pointer text-sm text-neutral-400">
                    <input type="checkbox" checked={form[c.key as keyof typeof form] as boolean} onChange={(e) => update(c.key, e.target.checked)} className="accent-gold w-4 h-4" />
                    {c.label}
                  </label>
                ))}
              </div>

              <div className="bg-gold/5 border border-gold/15 rounded-lg p-4 mb-6 flex items-center gap-3">
                <Upload className="w-5 h-5 text-gold shrink-0" />
                <p className="text-xs text-neutral-500">Podrás subir fotografías y documentos después de que nuestro equipo contacte tu solicitud.</p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-10 py-3 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-dark transition-colors disabled:opacity-50"
              >
                {loading ? 'Enviando...' : 'Enviar solicitud'}
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  )
}
