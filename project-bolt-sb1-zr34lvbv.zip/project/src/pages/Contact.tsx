import { useState } from 'react'
import { MapPin, Phone, Mail, Clock, MessageCircle, Send } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { COMPANY_ADDRESS, COMPANY_EMAIL, COMPANY_PHONE, WHATSAPP_NUMBER } from '../data/chile'
import SectionHeading from '../components/SectionHeading'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await supabase.from('contacts').insert({
      name: form.name, email: form.email, phone: form.phone,
      notes: `${form.subject ? `[${form.subject}] ` : ''}${form.message}`,
      source: 'web', type: 'buyer', status: 'nuevo',
    })
    setSent(true)
    setLoading(false)
  }

  const waMessage = encodeURIComponent('Hola, quiero información sobre los servicios de Terranova Propiedades.')
  const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${waMessage}`
  const inputCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-4 py-3 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 transition-colors'

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white">
            <span className="text-gold">Contáctenos</span>
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Estamos aquí para ayudarte con cualquier consulta sobre propiedades, arriendos o inversiones.
          </p>
        </div>
      </section>

      <section className="py-24 bg-[#141414]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact info */}
            <div className="space-y-8">
              {[
                { icon: MapPin, title: 'Dirección', value: COMPANY_ADDRESS },
                { icon: Phone, title: 'Teléfono', value: COMPANY_PHONE },
                { icon: Mail, title: 'Email', value: COMPANY_EMAIL },
                { icon: Clock, title: 'Horario', value: 'Lun–Vie: 9:00–18:00\nSáb: 10:00–14:00' },
              ].map((c) => (
                <div key={c.title} className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center shrink-0">
                    <c.icon className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <h3 className="text-xs font-semibold text-neutral-400 tracking-widest uppercase mb-1">{c.title}</h3>
                    <p className="text-neutral-300 text-sm whitespace-pre-line leading-relaxed">{c.value}</p>
                  </div>
                </div>
              ))}

              <a href={waUrl} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-4 bg-[#191919] border border-[#25D366]/20 rounded-xl p-5 hover:border-[#25D366]/40 transition-colors">
                <MessageCircle className="w-6 h-6 text-[#25D366] shrink-0" />
                <div>
                  <h3 className="text-sm font-semibold text-white">WhatsApp</h3>
                  <p className="text-xs text-neutral-500 mt-0.5">Respuesta inmediata</p>
                </div>
              </a>
            </div>

            {/* Form */}
            <div className="lg:col-span-2">
              {sent ? (
                <div className="text-center py-20 bg-[#191919] rounded-2xl border border-gold/15">
                  <div className="w-14 h-14 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-5">
                    <Send className="w-6 h-6 text-gold" />
                  </div>
                  <h3 className="font-heading text-2xl font-bold text-white">Mensaje enviado</h3>
                  <p className="mt-3 text-neutral-500">Nos pondremos en contacto contigo a la brevedad.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="bg-[#191919] rounded-2xl p-8 border border-gold/10">
                  <SectionHeading title="Envíanos un mensaje" light />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <input required placeholder="Nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} />
                    <input required type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} />
                    <input placeholder="Teléfono" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputCls} />
                    <input placeholder="Asunto" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className={inputCls} />
                  </div>
                  <textarea required placeholder="Tu mensaje" rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={`${inputCls} resize-none mb-5`} />
                  <button type="submit" disabled={loading}
                    className="w-full sm:w-auto px-10 py-3.5 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors disabled:opacity-50 text-sm tracking-wide">
                    {loading ? 'Enviando...' : 'Enviar mensaje'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
