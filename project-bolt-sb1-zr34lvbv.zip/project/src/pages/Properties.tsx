import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import type { Property, PropertyFilters as FiltersType } from '../types'
import PropertyCard from '../components/PropertyCard'
import PropertyFilters from '../components/PropertyFilters'
import PropertyMap from '../components/PropertyMap'
import SectionHeading from '../components/SectionHeading'
import { Map, LayoutGrid } from 'lucide-react'

const defaultFilters: FiltersType = {
  listing_type: '', property_type: '', region: '', comuna: '',
  price_min: '', price_max: '', m2_util_min: '', m2_util_max: '',
  m2_terreno_min: '', m2_terreno_max: '', dormitorios: '', banos: '', estacionamientos: '',
}

export default function Properties() {
  const [properties, setProperties] = useState<Property[]>([])
  const [filters, setFilters] = useState<FiltersType>(defaultFilters)
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid')

  useEffect(() => { searchProperties() }, [])

  async function searchProperties() {
    setLoading(true)
    let query = supabase.from('properties').select('*').eq('status', 'disponible')
    if (filters.listing_type) query = query.eq('listing_type', filters.listing_type)
    if (filters.property_type) query = query.eq('property_type', filters.property_type)
    if (filters.region) query = query.eq('region', filters.region)
    if (filters.comuna) query = query.eq('comuna', filters.comuna)
    if (filters.price_min) query = query.gte('price', Number(filters.price_min))
    if (filters.price_max) query = query.lte('price', Number(filters.price_max))
    if (filters.dormitorios) query = query.gte('dormitorios', Number(filters.dormitorios))
    if (filters.banos) query = query.gte('banos', Number(filters.banos))
    if (filters.estacionamientos) query = query.gte('estacionamientos', Number(filters.estacionamientos))
    if (filters.m2_util_min) query = query.gte('m2_util', Number(filters.m2_util_min))
    if (filters.m2_util_max) query = query.lte('m2_util', Number(filters.m2_util_max))
    if (filters.m2_terreno_min) query = query.gte('m2_terreno', Number(filters.m2_terreno_min))
    if (filters.m2_terreno_max) query = query.lte('m2_terreno', Number(filters.m2_terreno_max))
    const { data } = await query.order('featured', { ascending: false }).order('created_at', { ascending: false }).limit(100)
    setProperties(data || [])
    setLoading(false)
  }

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-14 border-b border-gold/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Propiedades" subtitle="Explora nuestro catálogo completo" light center />
          <PropertyFilters filters={filters} onChange={setFilters} onSearch={searchProperties} />

          <div className="mt-6 flex items-center justify-between">
            <p className="text-xs text-neutral-500 tracking-wide">
              {loading ? 'Buscando...' : `${properties.length} propiedades encontradas`}
            </p>
            <div className="flex gap-0.5 bg-[#1c1c1c] rounded-lg border border-gold/15 p-0.5">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded transition-colors ${viewMode === 'grid' ? 'bg-gold text-black-brand' : 'text-neutral-500 hover:text-neutral-300'}`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`p-2 rounded transition-colors ${viewMode === 'map' ? 'bg-gold text-black-brand' : 'text-neutral-500 hover:text-neutral-300'}`}
              >
                <Map className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-[#141414]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="rounded-xl overflow-hidden bg-[#191919]">
                  <div className="aspect-[4/3] animate-shimmer" />
                  <div className="p-5 space-y-3">
                    <div className="h-5 w-3/4 animate-shimmer rounded" />
                    <div className="h-4 w-1/2 animate-shimmer rounded" />
                    <div className="h-6 w-1/3 animate-shimmer rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : viewMode === 'map' ? (
            <div>
              <PropertyMap properties={properties} height="600px" />
              <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {properties.slice(0, 12).map((p) => (
                  <PropertyCard key={p.id} property={p} />
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {properties.map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
