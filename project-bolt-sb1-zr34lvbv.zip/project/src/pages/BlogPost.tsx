import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Calendar, ArrowLeft, Tag, ArrowRight } from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { BlogPost } from '../types'

const CATEGORY_LABELS: Record<string, string> = {
  noticias: 'Noticias', consejos: 'Consejos', mercado: 'Mercado', inversiones: 'Inversiones', legislacion: 'Legislación',
}

export default function BlogPostPage() {
  const { slug } = useParams()
  const [post, setPost] = useState<BlogPost | null>(null)
  const [related, setRelated] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadPost()
  }, [slug])

  async function loadPost() {
    if (!slug) return
    const { data } = await supabase.from('blog_posts').select('*').eq('slug', slug).eq('published', true).single()
    setPost(data)
    if (data) {
      const { data: rel } = await supabase.from('blog_posts').select('*').eq('published', true).eq('category', data.category).neq('id', data.id).limit(3)
      setRelated(rel || [])
    }
    setLoading(false)
  }

  if (loading) {
    return (
      <div className="pt-20 min-h-screen bg-black-brand">
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="animate-shimmer h-8 w-3/4 rounded mb-6" />
          <div className="animate-shimmer h-64 rounded-xl" />
        </div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="pt-20 min-h-screen bg-black-brand flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-heading text-2xl font-bold text-white">Artículo no encontrado</h2>
          <Link to="/blog" className="mt-4 inline-flex items-center gap-2 text-gold hover:text-gold-dark">
            <ArrowLeft className="w-4 h-4" /> Volver al blog
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/blog" className="inline-flex items-center gap-2 text-sm text-neutral-500 hover:text-gold mb-6">
          <ArrowLeft className="w-4 h-4" /> Blog
        </Link>

        <div className="mb-6">
          <div className="flex items-center gap-3 mb-3">
            <span className="px-3 py-1 text-xs bg-gold/10 text-gold rounded font-medium">
              {CATEGORY_LABELS[post.category]}
            </span>
            {post.published_at && (
              <span className="text-sm text-neutral-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {new Date(post.published_at).toLocaleDateString('es-CL', { year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            )}
          </div>
          <h1 className="font-heading text-3xl sm:text-4xl font-bold text-white">{post.title}</h1>
        </div>

        {post.image_url && (
          <img src={post.image_url} alt={post.title} className="w-full aspect-[16/9] object-cover rounded-xl mb-8" />
        )}

        <div className="bg-[#191919] rounded-xl p-6 sm:p-8 border border-gold/10">
          <div className="prose max-w-none text-neutral-400 leading-relaxed whitespace-pre-line">
            {post.content}
          </div>
        </div>

        {related.length > 0 && (
          <div className="mt-12">
            <h3 className="font-heading text-xl font-semibold text-white mb-4">Artículos relacionados</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {related.map((r) => (
                <Link
                  key={r.id}
                  to={`/blog/${r.slug}`}
                  className="group bg-[#191919] rounded-lg p-4 border border-gold/10 hover:border-gold/30 transition-all"
                >
                  <span className="text-xs px-2 py-0.5 bg-gold/10 text-gold rounded">{CATEGORY_LABELS[r.category]}</span>
                  <h4 className="mt-2 font-heading text-sm font-semibold text-white group-hover:text-gold transition-colors line-clamp-2">
                    {r.title}
                  </h4>
                  <span className="mt-2 inline-flex items-center gap-1 text-xs text-gold">
                    Leer <ArrowRight className="w-3 h-3" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </article>
    </div>
  )
}
