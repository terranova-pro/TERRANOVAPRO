import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { MapPin, Bed, Bath, Car, Maximize2, Ruler, Calendar, MessageCircle, ArrowLeft, Share2, ChevronLeft, ChevronRight } from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { Property } from '../types'
import { formatPrice } from '../components/PropertyCard'
import PropertyMap from '../components/PropertyMap'
import { WHATSAPP_NUMBER } from '../data/chile'

const LISTING_LABELS: Record<string, string> = {
  venta: 'Venta',
  arriendo: 'Arriendo',
  arriendo_diario: 'Arriendo Diario',
  arriendo_temporada: 'Arriendo Temporada',
}

const STATUS_WATERMARK: Record<string, string> = {
  vendida: 'VENDIDA',
  arrendada: 'ARRENDADA',
}

export default function PropertyDetail() {
  const { id } = useParams()
  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentImage, setCurrentImage] = useState(0)
  const [contactForm, setContactForm] = useState({ name: '', email: '', phone: '', message: '' })
  const [sent, setSent] = useState(false)

  useEffect(() => {
    loadProperty()
  }, [id])

  async function loadProperty() {
    if (!id) return
    const { data } = await supabase.from('properties').select('*').eq('id', id).single()
    setProperty(data)
    setLoading(false)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!property) return
    await supabase.from('contacts').insert({
      name: contactForm.name,
      email: contactForm.email,
      phone: contactForm.phone,
      notes: `Propiedad: ${property.title} (ID: ${property.id}). ${contactForm.message}`,
      source: 'web',
      type: property.listing_type === 'venta' ? 'buyer' : 'tenant',
      property_id: property.id,
      status: 'nuevo',
    })
    setSent(true)
  }

  if (loading) {
    return (
      <div className="pt-20 min-h-screen bg-black-brand">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="animate-shimmer h-80 rounded-xl" />
        </div>
      </div>
    )
  }

  if (!property) {
    return (
      <div className="pt-20 min-h-screen bg-black-brand flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-heading text-2xl font-bold text-white">Propiedad no encontrada</h2>
          <Link to="/propiedades" className="mt-4 inline-flex items-center gap-2 text-gold hover:text-gold-dark">
            <ArrowLeft className="w-4 h-4" /> Volver a propiedades
          </Link>
        </div>
      </div>
    )
  }

  const images = property.images?.length ? property.images : ['https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg']
  const waMessage = encodeURIComponent(`Hola, me interesa la propiedad: ${property.title} - ${property.comuna}`)
  const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${waMessage}`
  const watermark = STATUS_WATERMARK[property.status]

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/propiedades" className="inline-flex items-center gap-2 text-sm text-neutral-500 hover:text-gold mb-6">
          <ArrowLeft className="w-4 h-4" /> Volver a propiedades
        </Link>

        {/* Image gallery */}
        <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-black-brand mb-4">
          <img src={images[currentImage]} alt={property.title} className="w-full h-full object-cover" />
          {watermark && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
              <span className="text-white/80 text-5xl sm:text-6xl lg:text-7xl font-bold tracking-[0.15em] -rotate-12 border-[5px] border-white/60 px-10 py-4 rounded-lg bg-black/40 select-none">
                {watermark}
              </span>
            </div>
          )}
          {images.length > 1 && (
            <>
              <button
                onClick={() => setCurrentImage((prev) => (prev - 1 + images.length) % images.length)}
                className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/60 text-white p-2 rounded-full hover:bg-black/80 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setCurrentImage((prev) => (prev + 1) % images.length)}
                className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/60 text-white p-2 rounded-full hover:bg-black/80 transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}
          <div className="absolute top-4 left-4 flex gap-2">
            <span className="px-4 py-1.5 bg-gold text-black-brand text-sm font-semibold rounded">
              {LISTING_LABELS[property.listing_type]}
            </span>
            {property.featured && (
              <span className="px-4 py-1.5 bg-white text-black-brand text-sm font-semibold rounded">Destacada</span>
            )}
          </div>
        </div>

        {/* Thumbnails */}
        {images.length > 1 && (
          <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
            {images.map((img, i) => (
              <button
                key={i}
                onClick={() => setCurrentImage(i)}
                className={`shrink-0 w-20 h-14 rounded overflow-hidden border-2 transition-colors ${i === currentImage ? 'border-gold' : 'border-transparent opacity-60 hover:opacity-100'}`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Details */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-[#191919] rounded-xl p-6 border border-gold/10">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h1 className="font-heading text-2xl sm:text-3xl font-bold text-white">{property.title}</h1>
                  <div className="flex items-center gap-1.5 mt-2 text-neutral-500">
                    <MapPin className="w-4 h-4 text-gold" />
                    {property.address && <span>{property.address}, </span>}
                    {property.comuna}, {property.region}
                  </div>
                </div>
                <button className="p-2 border border-gold/20 rounded-lg text-neutral-400 hover:text-gold hover:border-gold/40 transition-colors">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
              <div className="mt-4 pt-4 border-t border-gold/10">
                <span className="font-heading text-3xl font-bold text-gold">
                  {formatPrice(property.price, property.currency, property.listing_type)}
                </span>
              </div>
            </div>

            <div className="bg-[#191919] rounded-xl p-6 border border-gold/10">
              <h2 className="font-heading text-xl font-semibold text-white mb-4">Características</h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {property.dormitorios != null && property.dormitorios > 0 && (
                  <div className="flex items-center gap-2">
                    <Bed className="w-5 h-5 text-gold" />
                    <div><div className="text-lg font-semibold text-white">{property.dormitorios}</div><div className="text-xs text-neutral-500">Dormitorios</div></div>
                  </div>
                )}
                {property.banos != null && property.banos > 0 && (
                  <div className="flex items-center gap-2">
                    <Bath className="w-5 h-5 text-gold" />
                    <div><div className="text-lg font-semibold text-white">{property.banos}</div><div className="text-xs text-neutral-500">Baños</div></div>
                  </div>
                )}
                {property.m2_util != null && property.m2_util > 0 && (
                  <div className="flex items-center gap-2">
                    <Maximize2 className="w-5 h-5 text-gold" />
                    <div><div className="text-lg font-semibold text-white">{property.m2_util}</div><div className="text-xs text-neutral-500">m² útiles</div></div>
                  </div>
                )}
                {property.m2_terreno != null && property.m2_terreno > 0 && (
                  <div className="flex items-center gap-2">
                    <Ruler className="w-5 h-5 text-gold" />
                    <div><div className="text-lg font-semibold text-white">{property.m2_terreno.toLocaleString()}</div><div className="text-xs text-neutral-500">m² terreno</div></div>
                  </div>
                )}
                {property.estacionamientos > 0 && (
                  <div className="flex items-center gap-2">
                    <Car className="w-5 h-5 text-gold" />
                    <div><div className="text-lg font-semibold text-white">{property.estacionamientos}</div><div className="text-xs text-neutral-500">Estacionamientos</div></div>
                  </div>
                )}
                {property.year_built && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-gold" />
                    <div><div className="text-lg font-semibold text-white">{property.year_built}</div><div className="text-xs text-neutral-500">Año construcción</div></div>
                  </div>
                )}
              </div>
            </div>

            {property.description && (
              <div className="bg-[#191919] rounded-xl p-6 border border-gold/10">
                <h2 className="font-heading text-xl font-semibold text-white mb-3">Descripción</h2>
                <p className="text-neutral-400 leading-relaxed whitespace-pre-line">{property.description}</p>
              </div>
            )}

            {property.latitude && property.longitude && (
              <div className="bg-[#191919] rounded-xl p-6 border border-gold/10">
                <h2 className="font-heading text-xl font-semibold text-white mb-3">Ubicación</h2>
                <PropertyMap properties={[property]} height="300px" />
              </div>
            )}
          </div>

          {/* Contact sidebar */}
          <div className="space-y-4">
            <div className="bg-[#191919] rounded-xl p-6 border border-gold/10 sticky top-24">
              <h3 className="font-heading text-lg font-semibold text-white mb-4">Consultar por esta propiedad</h3>
              {sent ? (
                <div className="text-center py-6">
                  <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <svg className="w-6 h-6 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <p className="text-sm text-neutral-400">Mensaje enviado correctamente. Nos contactaremos a la brevedad.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3">
                  <input required placeholder="Nombre completo" value={contactForm.name} onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                  <input required type="email" placeholder="Email" value={contactForm.email} onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                  <input required placeholder="Teléfono" value={contactForm.phone} onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50" />
                  <textarea placeholder="Mensaje" rows={3} value={contactForm.message} onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })} className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 resize-none" />
                  <button type="submit" className="w-full bg-gold hover:bg-gold-dark text-black-brand font-semibold py-2.5 rounded-lg transition-colors">
                    Enviar consulta
                  </button>
                </form>
              )}
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 w-full inline-flex items-center justify-center gap-2 bg-[#25D366] text-white font-semibold py-2.5 rounded-lg hover:bg-[#20bd5a] transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
            </div>

            {/* Portal integration note */}
            <div className="bg-[#191919] rounded-xl p-4 border border-gold/15">
              <p className="text-xs text-neutral-500">
                <strong className="text-gold">Integración con portales:</strong> Esta propiedad se publica automáticamente en Portal Inmobiliario, Propiedades Chile e Yapo, evitando doble publicación.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
