import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { TrendingUp, Shield, ArrowRight, Building2, TreePine, HandshakeIcon } from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { Property, PropertyFilters as FiltersType } from '../types'
import PropertyCard from '../components/PropertyCard'
import PropertyFilters from '../components/PropertyFilters'
import PropertyMap from '../components/PropertyMap'
import SectionHeading from '../components/SectionHeading'

const defaultFilters: FiltersType = {
  listing_type: '', property_type: '', region: '', comuna: '',
  price_min: '', price_max: '', m2_util_min: '', m2_util_max: '',
  m2_terreno_min: '', m2_terreno_max: '', dormitorios: '', banos: '', estacionamientos: '',
}

function TerranovaLogoHero() {
  return (
    <div className="flex flex-col items-center" style={{ gap: 0 }}>
      <div
        className="animate-float pointer-events-none"
        style={{ width: 'clamp(320px, 58vw, 640px)', marginBottom: -80, zIndex: 5, position: 'relative' }}
      >
        <svg viewBox="0 0 520 200" xmlns="http://www.w3.org/2000/svg" fill="none"
          className="w-full" style={{ color: '#C8A86B', opacity: 0.85 }}>
          <rect x="18" y="20" width="30" height="108" stroke="currentColor" strokeWidth="2.5"/>
          <rect x="52" y="36" width="24" height="92" stroke="currentColor" strokeWidth="2.5"/>
          <rect x="79" y="26" width="22" height="102" stroke="currentColor" strokeWidth="2.5"/>
          <rect x="104" y="50" width="18" height="78" stroke="currentColor" strokeWidth="2.5"/>
          <rect x="125" y="42" width="14" height="86" stroke="currentColor" strokeWidth="2.5"/>
          <rect x="24" y="33" width="8" height="8" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="36" y="33" width="8" height="8" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="24" y="50" width="8" height="8" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="36" y="50" width="8" height="8" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="57" y="48" width="7" height="7" stroke="currentColor" strokeWidth="1.2"/>
          <rect x="68" y="48" width="7" height="7" stroke="currentColor" strokeWidth="1.2"/>
          <path d="M8,128 C80,118 160,124 230,121 C300,118 380,122 450,119 C475,118 498,120 512,119" stroke="currentColor" strokeWidth="2.2"/>
          <path d="M8,137 C80,127 160,133 230,130 C300,127 380,131 450,128 C475,127 498,129 512,128" stroke="currentColor" strokeWidth="1.4"/>
          <rect x="200" y="88" width="74" height="42" stroke="currentColor" strokeWidth="2.5"/>
          <polyline points="190,88 237,50 284,88" stroke="currentColor" strokeWidth="2.5"/>
          <rect x="258" y="60" width="11" height="20" stroke="currentColor" strokeWidth="2"/>
          <rect x="211" y="96" width="20" height="20" stroke="currentColor" strokeWidth="2"/>
          <line x1="221" y1="96" x2="221" y2="116" stroke="currentColor" strokeWidth="1.5"/>
          <line x1="211" y1="106" x2="231" y2="106" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="241" y="107" width="16" height="23" stroke="currentColor" strokeWidth="2"/>
          <polyline points="315,128 363,42 403,90 436,28 480,98 512,80" stroke="currentColor" strokeWidth="2.5"/>
          <polyline points="352,68 363,42 374,68" stroke="currentColor" strokeWidth="1.5"/>
          <polyline points="296,128 345,72 388,105" stroke="currentColor" strokeWidth="2"/>
        </svg>
      </div>

      <div className="text-center animate-fade-in-up stagger-1" style={{ position: 'relative', zIndex: 10 }}>
        <h1
          className="text-white font-bold leading-none tracking-[0.12em]"
          style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(3rem, 9vw, 6rem)' }}
        >
          TERRANOVA
        </h1>
        <div className="flex items-center justify-center gap-4 mt-2">
          <div className="h-px flex-1 max-w-[80px] bg-gold/50" />
          <span className="text-gold tracking-[0.35em] text-xs sm:text-sm font-medium uppercase"
            style={{ fontFamily: "'Montserrat', sans-serif" }}>
            PROPIEDADES
          </span>
          <div className="h-px flex-1 max-w-[80px] bg-gold/50" />
        </div>
      </div>

      <p className="mt-4 text-neutral-500 text-center max-w-xl animate-fade-in-up stagger-2"
        style={{ fontFamily: "'Montserrat', sans-serif", fontSize: '0.8rem', letterSpacing: '0.03em' }}>
        Plataforma inmobiliaria premium para el mercado chileno.
        Venta, arriendo e inversión en todo Chile.
      </p>
    </div>
  )
}

export default function Home() {
  const [featured, setFeatured] = useState<Property[]>([])
  const [allProperties, setAllProperties] = useState<Property[]>([])
  const [filters, setFilters] = useState<FiltersType>(defaultFilters)
  const [showMap, setShowMap] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadFeatured(); loadAllForMap() }, [])

  async function loadFeatured() {
    const { data } = await supabase
      .from('properties').select('*')
      .eq('featured', true).eq('status', 'disponible')
      .order('created_at', { ascending: false }).limit(6)
    setFeatured(data || [])
    setLoading(false)
  }

  async function loadAllForMap() {
    const { data } = await supabase
      .from('properties').select('*')
      .eq('status', 'disponible')
      .not('latitude', 'is', null)
      .not('longitude', 'is', null)
      .order('created_at', { ascending: false }).limit(100)
    setAllProperties(data || [])
  }

  async function handleSearch() {
    setLoading(true)
    let query = supabase.from('properties').select('*').eq('status', 'disponible')
    if (filters.listing_type) query = query.eq('listing_type', filters.listing_type)
    if (filters.property_type) query = query.eq('property_type', filters.property_type)
    if (filters.region) query = query.eq('region', filters.region)
    if (filters.comuna) query = query.eq('comuna', filters.comuna)
    if (filters.price_min) query = query.gte('price', Number(filters.price_min))
    if (filters.price_max) query = query.lte('price', Number(filters.price_max))
    if (filters.dormitorios) query = query.gte('dormitorios', Number(filters.dormitorios))
    if (filters.banos) query = query.gte('banos', Number(filters.banos))
    if (filters.estacionamientos) query = query.gte('estacionamientos', Number(filters.estacionamientos))
    if (filters.m2_util_min) query = query.gte('m2_util', Number(filters.m2_util_min))
    if (filters.m2_util_max) query = query.lte('m2_util', Number(filters.m2_util_max))
    if (filters.m2_terreno_min) query = query.gte('m2_terreno', Number(filters.m2_terreno_min))
    if (filters.m2_terreno_max) query = query.lte('m2_terreno', Number(filters.m2_terreno_max))
    const { data } = await query.order('created_at', { ascending: false }).limit(50)
    setAllProperties(data || [])
    setShowMap(true)
    setLoading(false)
  }

  const displayProperties = showMap ? allProperties : featured

  return (
    <div className="bg-black-brand">
      {/* ── HERO ───────────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex flex-col items-center justify-center bg-black-brand overflow-hidden">
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 65% 50% at 50% 36%, rgba(200,168,107,0.06) 0%, transparent 70%)' }}
        />

        <div className="relative z-10 w-full px-[8%] flex flex-col items-center pt-28 pb-20 gap-14">
          <TerranovaLogoHero />

          <div className="w-12 h-px bg-gold/30 animate-fade-in-up stagger-2" />

          <div className="w-full animate-fade-in-up stagger-3">
            <PropertyFilters filters={filters} onChange={setFilters} onSearch={handleSearch} />
          </div>

          <div className="flex flex-wrap justify-center gap-8 animate-fade-in-up stagger-4 -mt-6">
            <button onClick={() => setShowMap(!showMap)}
              className="flex items-center gap-2 text-gold/70 hover:text-gold text-[11px] tracking-[0.2em] uppercase transition-colors">
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
              Ver en mapa
            </button>
            <Link to="/propiedades"
              className="flex items-center gap-2 text-neutral-600 hover:text-neutral-400 text-[11px] tracking-[0.2em] uppercase transition-colors">
              Listado completo <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-px bg-gold/10" />
      </section>

      {/* ── MAP RESULTS ────────────────────────────────────────────── */}
      {showMap && (
        <section className="py-20 bg-[#141414] border-t border-gold/10">
          <div className="px-[8%]">
            <SectionHeading title="Ubicación de nuestras propiedades" subtitle={`${allProperties.length} propiedades disponibles`} light />
            <PropertyMap properties={allProperties} height="480px" />
          </div>
        </section>
      )}

      {/* ── FEATURED PROPERTIES ────────────────────────────────────── */}
      <section className="py-24 bg-[#141414] border-t border-gold/10">
        <div className="px-[8%]">
          <SectionHeading
            title={showMap ? 'Propiedades encontradas' : 'Propiedades destacadas'}
            subtitle="Las mejores oportunidades del mercado inmobiliario chileno"
            light
          />
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="rounded-xl overflow-hidden bg-[#191919]">
                  <div className="aspect-[4/3] animate-shimmer" />
                  <div className="p-5 space-y-3">
                    <div className="h-5 w-3/4 animate-shimmer rounded" />
                    <div className="h-4 w-1/2 animate-shimmer rounded" />
                    <div className="h-6 w-1/3 animate-shimmer rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {displayProperties.slice(0, 6).map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          )}
          <div className="mt-14 text-center">
            <Link to="/propiedades"
              className="inline-flex items-center gap-3 px-10 py-4 border border-gold/40 text-gold font-semibold rounded-lg hover:bg-gold hover:text-black-brand transition-all tracking-wide text-base">
              Ver todas las propiedades <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── SERVICES ───────────────────────────────────────────────── */}
      <section className="pt-24 pb-40 bg-black-brand border-t border-gold/10">
        <div className="px-[8%]">
          <SectionHeading title="Nuestros Servicios" subtitle="Soluciones integrales para propietarios e inversionistas" light center />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-4">
            {[
              { icon: Building2, title: 'Vende con Terranova', desc: 'Vendemos tu propiedad al mejor precio con exposición premium en portales.', link: '/vende-con-terranova' },
              { icon: TreePine, title: 'Vende tu Terreno', desc: 'Especialistas en comercialización de terrenos urbanos y rurales.', link: '/vende-tu-terreno' },
              { icon: Shield, title: 'Administración', desc: 'Gestionamos tu propiedad con profesionalismo y transparencia total.', link: '/administracion' },
              { icon: TrendingUp, title: 'Inversiones', desc: 'Asesoría personalizada para maximizar tu retorno inmobiliario.', link: '/inversiones' },
            ].map((s) => (
              <Link key={s.title} to={s.link}
                className="group bg-[#191919] p-8 rounded-xl border border-gold/10 hover:border-gold/35 hover:shadow-2xl hover:shadow-black/50 transition-all">
                <div className="w-14 h-14 bg-gold/8 rounded-lg flex items-center justify-center mb-5 group-hover:bg-gold/15 transition-colors">
                  <s.icon className="w-7 h-7 text-gold" />
                </div>
                <h3 className="font-heading text-xl font-semibold text-white group-hover:text-gold transition-colors">{s.title}</h3>
                <p className="mt-3 text-sm text-neutral-500 leading-relaxed">{s.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── STATS + CTA ─────────────────────────────────────────── */}
      <section className="pt-40 pb-40 bg-[#141414] border-t border-b border-gold/10">
        <div className="w-full flex flex-col items-center px-6">
          <div className="flex justify-center gap-16 sm:gap-24 text-center mb-20">
            {[
              { value: '200+', label: 'Propiedades activas' },
              { value: '500+', label: 'Clientes satisfechos' },
            ].map((s) => (
              <div key={s.label}>
                <div className="font-heading text-5xl sm:text-6xl font-bold text-gold">{s.value}</div>
                <div className="mt-3 text-neutral-500 text-xs tracking-[0.2em] uppercase"
                  style={{ fontFamily: "'Montserrat', sans-serif" }}>{s.label}</div>
              </div>
            ))}
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-center">
            ¿Quieres vender o arrendar tu propiedad?
          </h2>
          <div className="mt-5 h-0.5 w-16 bg-gold mx-auto" />
          <p className="text-neutral-500 leading-relaxed text-center max-w-2xl mt-6 mb-14">
            Publicamos tu propiedad en los principales portales inmobiliarios de Chile para maximizar su exposición y reducir los tiempos de venta.
          </p>
          <div className="flex flex-col sm:flex-row gap-5 justify-center">
            <Link to="/vende-con-terranova"
              className="px-10 py-4 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors inline-flex items-center justify-center gap-3 tracking-wide text-base">
              <HandshakeIcon className="w-5 h-5" />
              Vende con Terranova
            </Link>
            <Link to="/vende-tu-terreno"
              className="px-10 py-4 border border-gold/40 text-gold font-semibold rounded-lg hover:bg-gold hover:text-black-brand transition-colors inline-flex items-center justify-center gap-3 tracking-wide text-base">
              <TreePine className="w-5 h-5" />
              Vende tu Terreno
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
