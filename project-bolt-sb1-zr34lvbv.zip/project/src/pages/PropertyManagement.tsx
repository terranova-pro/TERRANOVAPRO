import { Link } from 'react-router-dom'
import { Shield, FileText, TrendingUp, Clock, CheckCircle, ArrowRight } from 'lucide-react'
import SectionHeading from '../components/SectionHeading'
import { WHATSAPP_NUMBER } from '../data/chile'

export default function PropertyManagement() {
  const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Hola, me interesa el servicio de administración de propiedades.')}`
  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Shield className="w-12 h-12 text-gold mx-auto mb-5" />
          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white">
            Administración de <span className="text-gold">Propiedades</span>
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Gestionamos tu propiedad con profesionalismo, transparencia y máxima rentabilidad.
          </p>
        </div>
      </section>

      <section className="py-24 bg-[#141414] border-b border-gold/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Servicio integral" subtitle="Nos encargamos de todo para que tú solo recibas ingresos" light center />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {[
              { icon: FileText, title: 'Gestión de Contratos', desc: 'Redacción, renovación y terminación de contratos conforme a la legislación chilena vigente.' },
              { icon: TrendingUp, title: 'Optimización de Renta', desc: 'Análisis de mercado para fijar rentas competitivas que maximicen tu retorno de inversión.' },
              { icon: Clock, title: 'Cobro y Liquidación', desc: 'Cobro oportuno de arriendos, liquidación de gastos comunes y pago de servicios.' },
              { icon: Shield, title: 'Mantenimiento', desc: 'Coordinación de reparaciones y mantención preventiva para preservar el valor de tu propiedad.' },
              { icon: CheckCircle, title: 'Reportes Mensuales', desc: 'Estados de pago detallados, rendición de gastos y reportes de ocupación cada mes.' },
              { icon: ArrowRight, title: 'Selección de Arrendatarios', desc: 'Verificación de antecedentes comerciales, laborales y financieros de postulantes.' },
            ].map((s) => (
              <div key={s.title} className="bg-[#191919] p-8 rounded-xl border border-gold/10 hover:border-gold/25 transition-all">
                <s.icon className="w-8 h-8 text-gold mb-4" />
                <h3 className="font-heading text-xl font-semibold text-white">{s.title}</h3>
                <p className="mt-3 text-sm text-neutral-500 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>

          <SectionHeading title="Cómo funciona" light center />
          <div className="flex flex-col md:flex-row items-start justify-center gap-8 mb-20">
            {[
              { step: '1', title: 'Evaluación', desc: 'Inspección de la propiedad y análisis de mercado.' },
              { step: '2', title: 'Contrato', desc: 'Firma de mandato de administración.' },
              { step: '3', title: 'Gestión', desc: 'Publicación, selección y arriendo.' },
              { step: '4', title: 'Reportes', desc: 'Liquidación mensual y soporte continuo.' },
            ].map((s, i) => (
              <div key={s.step} className="flex items-start gap-4 md:flex-col md:items-center md:gap-3 md:text-center">
                <div className="w-12 h-12 bg-gold text-black-brand rounded-full flex items-center justify-center font-bold shrink-0">{s.step}</div>
                <div>
                  <h4 className="font-heading font-semibold text-white">{s.title}</h4>
                  <p className="text-xs text-neutral-500 mt-1 leading-relaxed">{s.desc}</p>
                </div>
                {i < 3 && <ArrowRight className="w-5 h-5 text-gold/30 hidden md:block mx-auto" />}
              </div>
            ))}
          </div>

          <div className="border border-gold/20 rounded-2xl p-10 sm:p-14 text-center">
            <h3 className="font-heading text-2xl font-bold text-white mb-4">Comisión transparente</h3>
            <p className="text-neutral-500 mb-8 max-w-lg mx-auto leading-relaxed">
              Nuestra comisión de administración es del <span className="text-gold font-semibold">10% + IVA</span> sobre la renta mensual. Sin costos ocultos, sin sorpresas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contacto"
                className="px-10 py-4 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors inline-flex items-center justify-center text-sm tracking-wide">
                Solicitar información
              </Link>
              <a href={waUrl} target="_blank" rel="noopener noreferrer"
                className="px-10 py-4 border border-gold/40 text-gold font-semibold rounded-lg hover:bg-gold hover:text-black-brand transition-colors inline-flex items-center justify-center text-sm tracking-wide">
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
