import { NavLink, useNavigate, Outlet } from 'react-router-dom'
import {
  LayoutDashboard, Building2, Users, Settings, LogOut, Shield,
} from 'lucide-react'
import { useAuth } from '../../lib/auth'

const ROLE_LABELS: Record<string, string> = {
  fundador: 'Fundador',
  administrador: 'Administrador',
  ejecutivo: 'Ejecutivo',
}

const ROLE_COLORS: Record<string, string> = {
  fundador: 'text-gold',
  administrador: 'text-blue-400',
  ejecutivo: 'text-emerald-400',
}

const navItems = [
  { to: '/intranet/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/intranet/propiedades', icon: Building2, label: 'Propiedades' },
  { to: '/intranet/ejecutivos', icon: Users, label: 'Ejecutivos' },
  { to: '/intranet/configuracion', icon: Settings, label: 'Configuración' },
]

export default function IntranetLayout() {
  const { profile, signOut } = useAuth()
  const navigate = useNavigate()

  async function handleSignOut() {
    await signOut()
    navigate('/intranet')
  }

  return (
    <div className="min-h-screen bg-[#0d0d0d] flex">
      {/* Sidebar */}
      <aside className="w-60 bg-[#111] border-r border-gold/10 flex flex-col shrink-0">
        {/* Logo */}
        <div className="px-6 py-6 border-b border-gold/10">
          <div className="flex flex-col">
            <span
              className="text-white font-bold text-lg leading-none tracking-wider"
              style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: '0.1em' }}
            >
              TERRANOVA
            </span>
            <div className="flex items-center gap-2 mt-1">
              <div className="h-px flex-1 max-w-[24px] bg-gold/40" />
              <span className="text-gold text-[8px] tracking-[0.3em] uppercase font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                INTRANET
              </span>
              <div className="h-px flex-1 max-w-[24px] bg-gold/40" />
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  isActive
                    ? 'bg-gold/10 text-gold border border-gold/20'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
                }`
              }
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="flex-1">{label}</span>
            </NavLink>
          ))}
        </nav>

        {/* User */}
        <div className="px-3 pb-4 border-t border-gold/10 pt-4 space-y-2">
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-8 h-8 rounded-full bg-gold/15 flex items-center justify-center shrink-0">
              <Shield className="w-4 h-4 text-gold" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs font-medium truncate">{profile?.full_name || 'Usuario'}</p>
              <p className={`text-[10px] font-medium ${ROLE_COLORS[profile?.role || 'ejecutivo']}`}>
                {ROLE_LABELS[profile?.role || 'ejecutivo']}
              </p>
            </div>
          </div>
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-500 hover:text-red-400 hover:bg-red-950/20 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Cerrar sesión
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 min-w-0 overflow-y-auto">
        <Outlet />
      </div>
    </div>
  )
}
