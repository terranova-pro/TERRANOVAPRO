import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/auth'
import { Check, Key, User } from 'lucide-react'

const fieldCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50'
const labelCls = 'block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase'

export default function Settings() {
  const { profile, user, refreshProfile } = useAuth()

  const [name, setName] = useState(profile?.full_name || '')
  const [phone, setPhone] = useState(profile?.phone || '')
  const [savingProfile, setSavingProfile] = useState(false)
  const [profileMsg, setProfileMsg] = useState('')

  const [currentPass, setCurrentPass] = useState('')
  const [newPass, setNewPass] = useState('')
  const [confirmPass, setConfirmPass] = useState('')
  const [savingPass, setSavingPass] = useState(false)
  const [passMsg, setPassMsg] = useState('')
  const [passErr, setPassErr] = useState('')

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault()
    setSavingProfile(true)
    await supabase.from('profiles').update({ full_name: name, phone: phone || null, updated_at: new Date().toISOString() }).eq('id', user!.id)
    await refreshProfile()
    setProfileMsg('Perfil actualizado correctamente.')
    setSavingProfile(false)
    setTimeout(() => setProfileMsg(''), 3000)
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault()
    setPassErr('')
    setPassMsg('')
    if (newPass !== confirmPass) { setPassErr('Las contraseñas no coinciden.'); return }
    if (newPass.length < 8) { setPassErr('La contraseña debe tener al menos 8 caracteres.'); return }
    setSavingPass(true)
    const { error } = await supabase.auth.updateUser({ password: newPass })
    if (error) { setPassErr(error.message) } else {
      setPassMsg('Contraseña actualizada correctamente.')
      setCurrentPass(''); setNewPass(''); setConfirmPass('')
    }
    setSavingPass(false)
    setTimeout(() => setPassMsg(''), 3000)
  }

  return (
    <div className="p-8 max-w-xl">
      <div className="mb-8">
        <h1 className="font-heading text-2xl font-bold text-white">Configuración</h1>
        <p className="text-neutral-500 text-sm mt-1">Ajustes de tu cuenta</p>
      </div>

      {/* Profile */}
      <div className="bg-[#141414] border border-gold/10 rounded-xl p-6 mb-6">
        <div className="flex items-center gap-2 mb-5">
          <User className="w-4 h-4 text-gold" />
          <h2 className="text-white font-semibold text-sm">Datos del perfil</h2>
        </div>
        <form onSubmit={saveProfile} className="space-y-4">
          <div>
            <label className={labelCls}>Nombre completo</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className={fieldCls} required />
          </div>
          <div>
            <label className={labelCls}>Correo (solo lectura)</label>
            <input value={user?.email || ''} disabled className={`${fieldCls} opacity-40 cursor-not-allowed`} />
          </div>
          <div>
            <label className={labelCls}>Teléfono</label>
            <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+56 9 XXXX XXXX" className={fieldCls} />
          </div>
          {profileMsg && <p className="text-emerald-400 text-sm">{profileMsg}</p>}
          <button type="submit" disabled={savingProfile} className="flex items-center gap-2 px-6 py-2.5 bg-gold text-black-brand font-semibold rounded-lg text-sm disabled:opacity-50">
            <Check className="w-4 h-4" /> {savingProfile ? 'Guardando...' : 'Guardar perfil'}
          </button>
        </form>
      </div>

      {/* Password */}
      <div className="bg-[#141414] border border-gold/10 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Key className="w-4 h-4 text-gold" />
          <h2 className="text-white font-semibold text-sm">Cambiar contraseña</h2>
        </div>
        <form onSubmit={savePassword} className="space-y-4">
          <div>
            <label className={labelCls}>Nueva contraseña</label>
            <input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="Mínimo 8 caracteres" className={fieldCls} required minLength={8} />
          </div>
          <div>
            <label className={labelCls}>Confirmar contraseña</label>
            <input type="password" value={confirmPass} onChange={(e) => setConfirmPass(e.target.value)} placeholder="Repite la contraseña" className={fieldCls} required />
          </div>
          {passErr && <p className="text-red-400 text-sm">{passErr}</p>}
          {passMsg && <p className="text-emerald-400 text-sm">{passMsg}</p>}
          <button type="submit" disabled={savingPass} className="flex items-center gap-2 px-6 py-2.5 bg-gold text-black-brand font-semibold rounded-lg text-sm disabled:opacity-50">
            <Key className="w-4 h-4" /> {savingPass ? 'Guardando...' : 'Cambiar contraseña'}
          </button>
        </form>
      </div>
    </div>
  )
}
