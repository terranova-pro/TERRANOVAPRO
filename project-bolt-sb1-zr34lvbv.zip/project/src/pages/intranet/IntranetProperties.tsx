import { useState, useEffect, useRef, useCallback } from 'react'
import { Plus, Pencil, Trash2, X, Check, Upload, Image, RefreshCw, Star, ImagePlus, GripVertical } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/auth'
import type { Property, PropertyType, ListingType, PropertyStatus } from '../../types'
import { REGIONS, COMUNAS_BY_REGION, PROPERTY_TYPES } from '../../data/chile'
import { parseProppitCSV } from '../../lib/proppitParser'

const LISTING_TYPES = [
  { value: 'venta', label: 'Venta' },
  { value: 'arriendo', label: 'Arriendo' },
  { value: 'arriendo_diario', label: 'Arriendo Diario' },
  { value: 'arriendo_temporada', label: 'Arriendo Temporada' },
]

const STATUS_OPTS = [
  { value: 'disponible', label: 'Disponible' },
  { value: 'reservada', label: 'Reservada' },
  { value: 'vendida', label: 'Vendida' },
  { value: 'arrendada', label: 'Arrendada' },
]

const STATUS_COLORS: Record<string, string> = {
  disponible: 'bg-emerald-900/40 text-emerald-400',
  reservada: 'bg-amber-900/40 text-amber-400',
  vendida: 'bg-blue-900/40 text-blue-400',
  arrendada: 'bg-neutral-800 text-neutral-400',
}

const MAX_FEATURED = 6
const BUCKET = 'property-images'

type FormData = {
  title: string; description: string; property_type: PropertyType | ''
  listing_type: ListingType | ''; price: string; currency: 'CLP' | 'UF'
  region: string; comuna: string; address: string; m2_util: string
  m2_terreno: string; dormitorios: string; banos: string; estacionamientos: string
  featured: boolean; status: PropertyStatus; assigned_to: string
  images: string[]
}

const emptyForm: FormData = {
  title: '', description: '', property_type: '', listing_type: '',
  price: '', currency: 'UF', region: '', comuna: '', address: '',
  m2_util: '', m2_terreno: '', dormitorios: '', banos: '', estacionamientos: '0',
  featured: false, status: 'disponible', assigned_to: '', images: [],
}

interface Profile { id: string; full_name: string; role: string }

function formatPrice(p: Property) {
  if (!p.price) return '—'
  return p.currency === 'UF'
    ? `UF ${p.price.toLocaleString('es-CL')}`
    : `$${p.price.toLocaleString('es-CL')}`
}

const fieldCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 appearance-none'
const labelCls = 'block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase'

// ── Image manager component ──────────────────────────────────────────────────

function ImageManager({ images, onChange }: { images: string[]; onChange: (imgs: string[]) => void }) {
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<string>('')
  const inputRef = useRef<HTMLInputElement>(null)

  async function handleFiles(files: FileList) {
    setUploading(true)
    const newUrls: string[] = []
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      const ext = file.name.split('.').pop()
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`
      setUploadProgress(`Subiendo ${i + 1} de ${files.length}…`)
      const { error } = await supabase.storage.from(BUCKET).upload(path, file, { upsert: false })
      if (!error) {
        const { data } = supabase.storage.from(BUCKET).getPublicUrl(path)
        newUrls.push(data.publicUrl)
      }
    }
    onChange([...images, ...newUrls])
    setUploading(false)
    setUploadProgress('')
    if (inputRef.current) inputRef.current.value = ''
  }

  function removeImage(idx: number) {
    onChange(images.filter((_, i) => i !== idx))
  }

  function moveUp(idx: number) {
    if (idx === 0) return
    const next = [...images]
    ;[next[idx - 1], next[idx]] = [next[idx], next[idx - 1]]
    onChange(next)
  }

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files)
  }, [images])

  return (
    <div className="space-y-3">
      {/* Upload zone */}
      <div
        onDrop={onDrop}
        onDragOver={(e) => e.preventDefault()}
        className="border-2 border-dashed border-gold/20 rounded-xl p-5 text-center hover:border-gold/40 transition-colors"
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp"
          multiple
          className="sr-only"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
        {uploading ? (
          <div className="flex items-center justify-center gap-2 text-gold text-sm">
            <RefreshCw className="w-4 h-4 animate-spin" />
            {uploadProgress}
          </div>
        ) : (
          <div>
            <ImagePlus className="w-7 h-7 text-gold/40 mx-auto mb-2" />
            <p className="text-neutral-500 text-sm mb-3">
              Arrastra fotos aquí o{' '}
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="text-gold underline underline-offset-2 hover:text-gold-light"
              >
                selecciona archivos
              </button>
            </p>
            <p className="text-neutral-700 text-xs">JPG, PNG, WEBP · Máx. 10 MB por foto</p>
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {images.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] text-neutral-600 uppercase tracking-wider">
            La primera foto es la imagen principal
          </p>
          <div className="grid grid-cols-3 gap-2">
            {images.map((url, i) => (
              <div
                key={url}
                className={`relative rounded-lg overflow-hidden aspect-video bg-[#1c1c1c] group border ${i === 0 ? 'border-gold/50' : 'border-white/5'}`}
              >
                <img src={url} alt="" className="w-full h-full object-cover" />
                {i === 0 && (
                  <div className="absolute top-1 left-1 bg-gold text-black-brand text-[9px] font-bold px-1.5 py-0.5 rounded tracking-wider">
                    PRINCIPAL
                  </div>
                )}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5">
                  {i > 0 && (
                    <button
                      type="button"
                      onClick={() => moveUp(i)}
                      title="Mover a principal"
                      className="p-1 bg-gold/90 text-black rounded hover:bg-gold"
                    >
                      <GripVertical className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => removeImage(i)}
                    className="p-1 bg-red-600/90 text-white rounded hover:bg-red-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main component ───────────────────────────────────────────────────────────

export default function IntranetProperties() {
  const { profile: me } = useAuth()
  const [properties, setProperties] = useState<Property[]>([])
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Property | null>(null)
  const [form, setForm] = useState<FormData>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [importing, setImporting] = useState(false)
  const [importResult, setImportResult] = useState<{ added: number; updated: number } | null>(null)
  const csvRef = useRef<HTMLInputElement>(null)

  const canManageFeatured = me?.role === 'fundador' || me?.role === 'administrador'
  const featuredCount = properties.filter((p) => p.featured).length
  const comunas = form.region ? COMUNAS_BY_REGION[form.region] || [] : []

  useEffect(() => {
    loadProperties()
    supabase.from('profiles').select('id, full_name, role').eq('is_active', true)
      .then(({ data }) => setProfiles(data || []))
  }, [])

  async function loadProperties() {
    setLoading(true)
    const { data } = await supabase.from('properties').select('*').order('created_at', { ascending: false })
    setProperties(data || [])
    setLoading(false)
  }

  function openNew() { setEditing(null); setForm(emptyForm); setShowForm(true) }

  function openEdit(p: Property) {
    setEditing(p)
    setForm({
      title: p.title, description: p.description || '', property_type: p.property_type,
      listing_type: p.listing_type, price: p.price?.toString() || '', currency: p.currency,
      region: p.region, comuna: p.comuna, address: p.address || '',
      m2_util: p.m2_util?.toString() || '', m2_terreno: p.m2_terreno?.toString() || '',
      dormitorios: p.dormitorios?.toString() || '', banos: p.banos?.toString() || '',
      estacionamientos: p.estacionamientos?.toString() || '0', featured: p.featured,
      status: p.status, images: p.images || [],
      assigned_to: (p as unknown as { assigned_to?: string }).assigned_to || '',
    })
    setShowForm(true)
  }

  function update<K extends keyof FormData>(key: K, value: FormData[K]) {
    setForm((prev) => {
      const next = { ...prev, [key]: value }
      if (key === 'region') (next as FormData).comuna = ''
      return next
    })
  }

  async function toggleFeatured(p: Property) {
    if (!canManageFeatured) return
    if (!p.featured && featuredCount >= MAX_FEATURED) return
    await supabase.from('properties').update({ featured: !p.featured, updated_at: new Date().toISOString() }).eq('id', p.id)
    loadProperties()
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    const payload: Record<string, unknown> = {
      title: form.title, description: form.description || null,
      property_type: form.property_type as PropertyType, listing_type: form.listing_type as ListingType,
      price: form.price ? Number(form.price) : null, currency: form.currency,
      region: form.region, comuna: form.comuna, address: form.address || null,
      m2_util: form.m2_util ? Number(form.m2_util) : null,
      m2_terreno: form.m2_terreno ? Number(form.m2_terreno) : null,
      dormitorios: form.dormitorios ? Number(form.dormitorios) : null,
      banos: form.banos ? Number(form.banos) : null,
      estacionamientos: Number(form.estacionamientos) || 0,
      featured: canManageFeatured ? form.featured : (editing?.featured ?? false),
      status: form.status, images: form.images,
      assigned_to: form.assigned_to || null,
      updated_at: new Date().toISOString(),
    }
    if (editing) {
      await supabase.from('properties').update(payload).eq('id', editing.id)
    } else {
      await supabase.from('properties').insert(payload)
    }
    await loadProperties()
    setShowForm(false)
    setSaving(false)
  }

  async function handleDelete(id: string) {
    await supabase.from('properties').delete().eq('id', id)
    setDeleteId(null)
    await loadProperties()
  }

  async function handleCSVImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setImporting(true)
    setImportResult(null)
    const text = await file.text()
    const listings = parseProppitCSV(text)
    let added = 0; let updated = 0
    for (const listing of listings) {
      const { data: existing } = await supabase
        .from('properties').select('id').eq('proppit_ref', listing.proppit_ref).maybeSingle()
      const row = { ...listing, updated_at: new Date().toISOString() }
      if (existing) {
        await supabase.from('properties').update(row).eq('id', existing.id)
        updated++
      } else {
        await supabase.from('properties').insert({ ...row, status: 'disponible' })
        added++
      }
    }
    await loadProperties()
    setImportResult({ added, updated })
    setImporting(false)
    if (csvRef.current) csvRef.current.value = ''
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <h1 className="font-heading text-2xl font-bold text-white">Propiedades</h1>
          <p className="text-neutral-500 text-sm mt-1">{properties.length} propiedades en total</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="relative cursor-pointer">
            <input type="file" accept=".csv" ref={csvRef} onChange={handleCSVImport} className="sr-only" />
            <span className={`flex items-center gap-2 px-4 py-2.5 border border-gold/30 text-gold rounded-lg hover:bg-gold/10 transition-colors text-sm font-medium ${importing ? 'opacity-50 pointer-events-none' : ''}`}>
              {importing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {importing ? 'Importando...' : 'Importar Proppit CSV'}
            </span>
          </label>
          <button onClick={openNew} className="flex items-center gap-2 px-5 py-2.5 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors text-sm">
            <Plus className="w-4 h-4" /> Nueva
          </button>
        </div>
      </div>

      {/* Featured counter */}
      {canManageFeatured && (
        <div className="mb-5 flex items-center gap-3 px-4 py-3 bg-[#141414] border border-gold/15 rounded-xl">
          <Star className="w-4 h-4 text-gold shrink-0" />
          <div className="flex-1">
            <span className="text-sm text-neutral-300">Vitrina destacada: </span>
            <span className={`font-semibold text-sm ${featuredCount >= MAX_FEATURED ? 'text-amber-400' : 'text-gold'}`}>
              {featuredCount} / {MAX_FEATURED}
            </span>
            <span className="text-neutral-600 text-xs ml-2">
              {featuredCount >= MAX_FEATURED
                ? '— Vitrina llena. Quita una antes de destacar otra.'
                : `— ${MAX_FEATURED - featuredCount} espacio${MAX_FEATURED - featuredCount !== 1 ? 's' : ''} libre${MAX_FEATURED - featuredCount !== 1 ? 's' : ''}`}
            </span>
          </div>
          <div className="flex gap-1">
            {Array.from({ length: MAX_FEATURED }).map((_, i) => (
              <div key={i} className={`w-5 h-2 rounded-sm ${i < featuredCount ? 'bg-gold' : 'bg-neutral-700'}`} />
            ))}
          </div>
        </div>
      )}

      {importResult && (
        <div className="mb-5 px-5 py-3.5 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-emerald-400 text-sm flex items-center justify-between">
          <span>Importación completada: <strong>{importResult.added}</strong> nuevas, <strong>{importResult.updated}</strong> actualizadas.</span>
          <button onClick={() => setImportResult(null)} className="text-emerald-600 hover:text-emerald-400"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Table */}
      {loading ? (
        <div className="space-y-2">{[1, 2, 3, 4].map((i) => <div key={i} className="bg-[#141414] rounded-xl h-14 animate-pulse" />)}</div>
      ) : (
        <div className="bg-[#141414] rounded-xl border border-gold/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-[#111] border-b border-gold/10">
                  <th className="text-left px-4 py-3 font-medium text-neutral-500 text-xs">Propiedad</th>
                  <th className="text-left px-4 py-3 font-medium text-neutral-500 text-xs">Tipo</th>
                  <th className="text-left px-4 py-3 font-medium text-neutral-500 text-xs">Precio</th>
                  <th className="text-left px-4 py-3 font-medium text-neutral-500 text-xs">Estado</th>
                  <th className="text-left px-4 py-3 font-medium text-neutral-500 text-xs">Ejecutivo</th>
                  {canManageFeatured && (
                    <th className="text-left px-4 py-3 font-medium text-neutral-500 text-xs">
                      <div className="flex items-center gap-1"><Star className="w-3 h-3" /> Vitrina</div>
                    </th>
                  )}
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {properties.map((p) => {
                  const mainImage = p.images?.[0] ?? null
                  const atMax = featuredCount >= MAX_FEATURED && !p.featured
                  return (
                    <tr key={p.id} className="border-b border-gold/5 hover:bg-[#1a1a1a] transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          {mainImage ? (
                            <img src={mainImage} alt="" className="w-10 h-10 rounded-lg object-cover shrink-0" />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-[#222] flex items-center justify-center shrink-0">
                              <Image className="w-4 h-4 text-neutral-700" />
                            </div>
                          )}
                          <div>
                            <div className="text-white text-xs font-medium max-w-[200px] truncate">{p.title}</div>
                            <div className="text-[10px] text-neutral-500 mt-0.5">{p.comuna}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-neutral-400 text-xs capitalize">{p.property_type} / {p.listing_type}</td>
                      <td className="px-4 py-3 text-gold font-semibold text-xs">{formatPrice(p)}</td>
                      <td className="px-4 py-3">
                        <select
                          value={p.status}
                          onChange={async (e) => {
                            await supabase.from('properties').update({ status: e.target.value, updated_at: new Date().toISOString() }).eq('id', p.id)
                            loadProperties()
                          }}
                          className={`text-xs px-2 py-1 rounded border-0 outline-none cursor-pointer ${STATUS_COLORS[p.status]} bg-transparent`}
                        >
                          {STATUS_OPTS.map((s) => (
                            <option key={s.value} value={s.value} className="bg-[#1c1c1c] text-neutral-300">{s.label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-3 text-neutral-500 text-xs">
                        {profiles.find((pr) => pr.id === (p as unknown as { assigned_to?: string }).assigned_to)?.full_name || '—'}
                      </td>
                      {canManageFeatured && (
                        <td className="px-4 py-3">
                          <button
                            onClick={() => toggleFeatured(p)}
                            disabled={atMax}
                            title={atMax ? 'Vitrina llena (máx. 6)' : p.featured ? 'Quitar de vitrina' : 'Agregar a vitrina'}
                            className={`flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-lg font-medium transition-all border
                              ${p.featured
                                ? 'bg-gold/15 text-gold border-gold/30 hover:bg-gold/25'
                                : atMax
                                  ? 'bg-neutral-900 text-neutral-700 border-neutral-800 cursor-not-allowed'
                                  : 'bg-neutral-800/60 text-neutral-400 border-neutral-700 hover:bg-gold/10 hover:text-gold hover:border-gold/30'
                              }`}
                          >
                            <Star className={`w-3 h-3 ${p.featured ? 'fill-gold text-gold' : ''}`} />
                            {p.featured ? 'Destacada' : 'Destacar'}
                          </button>
                        </td>
                      )}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 justify-end">
                          <button onClick={() => openEdit(p)} className="p-1.5 text-neutral-600 hover:text-gold transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                          <button onClick={() => setDeleteId(p.id)} className="p-1.5 text-neutral-600 hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
                {properties.length === 0 && (
                  <tr><td colSpan={canManageFeatured ? 7 : 6} className="px-4 py-10 text-center text-neutral-600 text-sm">Sin propiedades. Agrega una o importa desde Proppit.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 px-4">
          <div className="bg-[#141414] border border-gold/15 rounded-2xl p-8 max-w-sm w-full text-center">
            <h3 className="font-heading text-xl font-bold text-white mb-3">Eliminar propiedad</h3>
            <p className="text-neutral-400 text-sm mb-6">Esta acción es irreversible.</p>
            <div className="flex gap-3 justify-center">
              <button onClick={() => setDeleteId(null)} className="px-6 py-2.5 border border-gold/20 text-neutral-300 rounded-lg text-sm hover:border-gold/40 transition-colors">Cancelar</button>
              <button onClick={() => handleDelete(deleteId)} className="px-6 py-2.5 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700 transition-colors">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/85 flex items-start justify-center z-50 overflow-y-auto py-8 px-4">
          <div className="bg-[#141414] border border-gold/15 rounded-2xl w-full max-w-2xl">
            <div className="flex items-center justify-between p-6 border-b border-gold/10">
              <h3 className="font-heading text-xl font-semibold text-white">
                {editing ? 'Editar propiedad' : 'Nueva propiedad'}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-2 text-neutral-500 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-5">
              {/* Title */}
              <div>
                <label className={labelCls}>Título *</label>
                <input required value={form.title} onChange={(e) => update('title', e.target.value)} placeholder="Ej: Departamento 2D2B | Las Condes" className={fieldCls} />
              </div>

              {/* Type + Listing */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Tipo *</label>
                  <select required value={form.property_type} onChange={(e) => update('property_type', e.target.value as PropertyType)} className={fieldCls}>
                    <option value="">Seleccionar</option>
                    {PROPERTY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Operación *</label>
                  <select required value={form.listing_type} onChange={(e) => update('listing_type', e.target.value as ListingType)} className={fieldCls}>
                    <option value="">Seleccionar</option>
                    {LISTING_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
              </div>

              {/* Price */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Precio</label>
                  <input type="number" value={form.price} onChange={(e) => update('price', e.target.value)} placeholder="Ej: 3500 o 85000000" className={fieldCls} />
                </div>
                <div>
                  <label className={labelCls}>Moneda</label>
                  <select value={form.currency} onChange={(e) => update('currency', e.target.value as 'CLP' | 'UF')} className={fieldCls}>
                    <option value="UF">UF</option>
                    <option value="CLP">CLP (pesos)</option>
                  </select>
                </div>
              </div>

              {/* Location */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Región *</label>
                  <select required value={form.region} onChange={(e) => update('region', e.target.value)} className={fieldCls}>
                    <option value="">Seleccionar</option>
                    {REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Comuna *</label>
                  <select required value={form.comuna} onChange={(e) => update('comuna', e.target.value)} className={fieldCls} disabled={!comunas.length}>
                    <option value="">Seleccionar</option>
                    {comunas.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className={labelCls}>Dirección</label>
                <input value={form.address} onChange={(e) => update('address', e.target.value)} placeholder="Ej: Av. Providencia 1234" className={fieldCls} />
              </div>

              {/* Specs */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className={labelCls}>m² útiles</label>
                  <input type="number" value={form.m2_util} onChange={(e) => update('m2_util', e.target.value)} className={fieldCls} />
                </div>
                <div>
                  <label className={labelCls}>m² terreno</label>
                  <input type="number" value={form.m2_terreno} onChange={(e) => update('m2_terreno', e.target.value)} className={fieldCls} />
                </div>
                <div>
                  <label className={labelCls}>Dormitorios</label>
                  <input type="number" value={form.dormitorios} onChange={(e) => update('dormitorios', e.target.value)} className={fieldCls} />
                </div>
                <div>
                  <label className={labelCls}>Baños</label>
                  <input type="number" value={form.banos} onChange={(e) => update('banos', e.target.value)} className={fieldCls} />
                </div>
                <div>
                  <label className={labelCls}>Estac.</label>
                  <input type="number" value={form.estacionamientos} onChange={(e) => update('estacionamientos', e.target.value)} className={fieldCls} />
                </div>
                <div>
                  <label className={labelCls}>Estado</label>
                  <select value={form.status} onChange={(e) => update('status', e.target.value as PropertyStatus)} className={fieldCls}>
                    {STATUS_OPTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                </div>
              </div>

              {/* Executive */}
              <div>
                <label className={labelCls}>Asignar a ejecutivo</label>
                <select value={form.assigned_to} onChange={(e) => update('assigned_to', e.target.value)} className={fieldCls}>
                  <option value="">Sin asignar</option>
                  {profiles.map((pr) => <option key={pr.id} value={pr.id}>{pr.full_name}</option>)}
                </select>
              </div>

              {/* Photos */}
              <div>
                <label className={labelCls}>Fotografías</label>
                <ImageManager images={form.images} onChange={(imgs) => update('images', imgs)} />
              </div>

              {/* Description */}
              <div>
                <label className={labelCls}>Descripción</label>
                <textarea value={form.description} onChange={(e) => update('description', e.target.value)} rows={5} className={`${fieldCls} resize-none`} />
              </div>

              {/* Featured toggle — fundador/admin only */}
              {canManageFeatured && (
                <div className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${form.featured ? 'bg-gold/8 border-gold/25' : 'border-neutral-800'}`}>
                  <label className="flex items-center gap-3 cursor-pointer flex-1">
                    <input
                      type="checkbox"
                      checked={form.featured}
                      onChange={(e) => {
                        if (e.target.checked && featuredCount >= MAX_FEATURED && !editing?.featured) return
                        update('featured', e.target.checked)
                      }}
                      disabled={!form.featured && featuredCount >= MAX_FEATURED && !editing?.featured}
                      className="accent-gold w-4 h-4 shrink-0"
                    />
                    <div>
                      <span className="text-sm text-neutral-300 font-medium">Incluir en Sección Destacada</span>
                      <p className="text-[10px] text-neutral-600 mt-0.5">Aparece en la vitrina principal del sitio web</p>
                    </div>
                  </label>
                  <span className={`text-[10px] shrink-0 font-medium ${featuredCount >= MAX_FEATURED ? 'text-amber-400' : 'text-neutral-600'}`}>
                    {featuredCount}/{MAX_FEATURED}
                  </span>
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center gap-3 pt-2 border-t border-gold/10">
                <button type="submit" disabled={saving} className="flex items-center gap-2 px-8 py-3 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors disabled:opacity-50 text-sm">
                  <Check className="w-4 h-4" />
                  {saving ? 'Guardando...' : editing ? 'Guardar cambios' : 'Publicar'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="px-6 py-3 border border-gold/20 text-neutral-400 rounded-lg text-sm hover:border-gold/40 transition-colors">
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
