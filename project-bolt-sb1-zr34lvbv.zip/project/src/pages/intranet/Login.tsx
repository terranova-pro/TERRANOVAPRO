import { useState } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../lib/auth'
import { Eye, EyeOff, Lock, Mail, ArrowLeft } from 'lucide-react'

type View = 'login' | 'forgot' | 'forgot_sent'

const fieldCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg pl-10 pr-4 py-3 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50'

export default function Login() {
  const { signIn, resetPassword, session } = useAuth()
  const location = useLocation()
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/intranet/dashboard'

  const [view, setView] = useState<View>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [resetEmail, setResetEmail] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  if (session) return <Navigate to={from} replace />

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const err = await signIn(email, password)
    if (err) setError(err)
    setLoading(false)
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const err = await resetPassword(resetEmail)
    if (err) {
      setError('No se pudo enviar el correo. Verifica la dirección e intenta nuevamente.')
    } else {
      setView('forgot_sent')
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <span
            className="text-white font-bold text-3xl leading-none tracking-wider"
            style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: '0.12em' }}
          >
            TERRANOVA
          </span>
          <div className="flex items-center justify-center gap-3 mt-1.5">
            <div className="h-px w-8 bg-gold/50" />
            <span className="text-gold text-[9px] tracking-[0.35em] uppercase font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              INTRANET
            </span>
            <div className="h-px w-8 bg-gold/50" />
          </div>
        </div>

        {/* Card */}
        <div className="bg-[#141414] border border-gold/15 rounded-2xl p-8">
          {/* LOGIN */}
          {view === 'login' && (
            <>
              <h1 className="text-white text-xl font-semibold mb-6 font-heading">Iniciar sesión</h1>
              {error && (
                <div className="mb-5 px-4 py-3 bg-red-950/50 border border-red-500/30 rounded-lg text-red-400 text-sm">
                  {error}
                </div>
              )}
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase">
                    Correo electrónico
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-600" />
                    <input
                      type="email" required value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="correo@ejemplo.com"
                      className={fieldCls}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase">
                    Contraseña
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-600" />
                    <input
                      type={showPass ? 'text' : 'password'}
                      required value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg pl-10 pr-10 py-3 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-600 hover:text-neutral-400"
                    >
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <button
                  type="submit" disabled={loading}
                  className="w-full py-3 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors disabled:opacity-50 text-sm mt-2"
                >
                  {loading ? 'Verificando...' : 'Ingresar'}
                </button>
              </form>
              <p className="mt-6 text-center text-neutral-600 text-xs">
                ¿Olvidaste tu contraseña?{' '}
                <button
                  onClick={() => { setView('forgot'); setError(''); setResetEmail(email) }}
                  className="text-gold/70 hover:text-gold underline underline-offset-2 transition-colors"
                >
                  Recuperar acceso
                </button>
              </p>
            </>
          )}

          {/* FORGOT PASSWORD */}
          {view === 'forgot' && (
            <>
              <button
                onClick={() => { setView('login'); setError('') }}
                className="flex items-center gap-1.5 text-neutral-500 hover:text-gold text-xs mb-6 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Volver al inicio de sesión
              </button>
              <h1 className="text-white text-xl font-semibold mb-2 font-heading">Recuperar contraseña</h1>
              <p className="text-neutral-500 text-sm mb-6">
                Ingresa tu correo y te enviaremos un enlace para restablecer tu contraseña.
              </p>
              {error && (
                <div className="mb-5 px-4 py-3 bg-red-950/50 border border-red-500/30 rounded-lg text-red-400 text-sm">
                  {error}
                </div>
              )}
              <form onSubmit={handleForgot} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase">
                    Correo electrónico
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-600" />
                    <input
                      type="email" required value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      placeholder="correo@ejemplo.com"
                      className={fieldCls}
                    />
                  </div>
                </div>
                <button
                  type="submit" disabled={loading}
                  className="w-full py-3 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors disabled:opacity-50 text-sm"
                >
                  {loading ? 'Enviando...' : 'Enviar enlace de recuperación'}
                </button>
              </form>
            </>
          )}

          {/* FORGOT SENT */}
          {view === 'forgot_sent' && (
            <div className="text-center py-4">
              <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-5">
                <Mail className="w-6 h-6 text-gold" />
              </div>
              <h1 className="text-white text-xl font-semibold mb-2 font-heading">Correo enviado</h1>
              <p className="text-neutral-400 text-sm mb-6 leading-relaxed">
                Hemos enviado un enlace de recuperación a{' '}
                <span className="text-gold">{resetEmail}</span>.
                Revisa tu bandeja de entrada y sigue las instrucciones.
              </p>
              <button
                onClick={() => { setView('login'); setError('') }}
                className="text-gold/70 hover:text-gold text-xs underline underline-offset-2 transition-colors"
              >
                Volver al inicio de sesión
              </button>
            </div>
          )}
        </div>

        <p className="mt-6 text-center text-neutral-700 text-xs">
          Acceso restringido — Solo personal autorizado
        </p>
      </div>
    </div>
  )
}
