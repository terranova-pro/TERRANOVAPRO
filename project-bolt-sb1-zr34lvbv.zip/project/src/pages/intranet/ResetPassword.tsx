import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../lib/auth'
import { Eye, EyeOff, Key, Check } from 'lucide-react'
import { supabase } from '../../lib/supabase'

export default function ResetPassword() {
  const { updatePassword } = useAuth()
  const navigate = useNavigate()

  const [ready, setReady] = useState(false)
  const [newPass, setNewPass] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [done, setDone] = useState(false)

  useEffect(() => {
    // Supabase redirects with access_token in the URL hash after password reset
    supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        setReady(true)
      }
    })
    // Also check if session already exists (token was consumed)
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) setReady(true)
    })
  }, [])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (newPass.length < 8) { setError('La contraseña debe tener al menos 8 caracteres.'); return }
    if (newPass !== confirm) { setError('Las contraseñas no coinciden.'); return }
    setLoading(true)
    const err = await updatePassword(newPass)
    if (err) {
      setError(err)
    } else {
      setDone(true)
      setTimeout(() => navigate('/intranet/dashboard'), 2500)
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <span
            className="text-white font-bold text-3xl leading-none tracking-wider"
            style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: '0.12em' }}
          >
            TERRANOVA
          </span>
          <div className="flex items-center justify-center gap-3 mt-1.5">
            <div className="h-px w-8 bg-gold/50" />
            <span className="text-gold text-[9px] tracking-[0.35em] uppercase font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              INTRANET
            </span>
            <div className="h-px w-8 bg-gold/50" />
          </div>
        </div>

        <div className="bg-[#141414] border border-gold/15 rounded-2xl p-8">
          {done ? (
            <div className="text-center py-4">
              <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-5">
                <Check className="w-6 h-6 text-gold" />
              </div>
              <h1 className="text-white text-xl font-semibold mb-2 font-heading">Contraseña actualizada</h1>
              <p className="text-neutral-400 text-sm">Redirigiendo al panel...</p>
            </div>
          ) : !ready ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 border-2 border-gold/30 border-t-gold rounded-full animate-spin mx-auto mb-4" />
              <p className="text-neutral-500 text-sm">Verificando enlace...</p>
            </div>
          ) : (
            <>
              <h1 className="text-white text-xl font-semibold mb-2 font-heading">Nueva contraseña</h1>
              <p className="text-neutral-500 text-sm mb-6">Elige una contraseña segura de al menos 8 caracteres.</p>
              {error && (
                <div className="mb-5 px-4 py-3 bg-red-950/50 border border-red-500/30 rounded-lg text-red-400 text-sm">
                  {error}
                </div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase">
                    Nueva contraseña
                  </label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-600" />
                    <input
                      type={showPass ? 'text' : 'password'}
                      required minLength={8} value={newPass}
                      onChange={(e) => setNewPass(e.target.value)}
                      placeholder="Mínimo 8 caracteres"
                      className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg pl-10 pr-10 py-3 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-600 hover:text-neutral-400"
                    >
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase">
                    Confirmar contraseña
                  </label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-600" />
                    <input
                      type={showPass ? 'text' : 'password'}
                      required value={confirm}
                      onChange={(e) => setConfirm(e.target.value)}
                      placeholder="Repite la contraseña"
                      className="w-full bg-[#1c1c1c] border border-gold/20 rounded-lg pl-10 pr-4 py-3 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50"
                    />
                  </div>
                </div>
                <button
                  type="submit" disabled={loading}
                  className="w-full py-3 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors disabled:opacity-50 text-sm"
                >
                  {loading ? 'Guardando...' : 'Establecer nueva contraseña'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
