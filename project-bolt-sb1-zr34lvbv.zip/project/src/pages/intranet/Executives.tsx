import { useState, useEffect } from 'react'
import { Plus, Pencil, Trash2, X, Check, Shield } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../lib/auth'

interface Profile {
  id: string; full_name: string; role: string; phone: string | null
  email: string | null; is_active: boolean; created_at: string
}

interface InviteForm { email: string; full_name: string; password: string; role: string }

const ROLE_OPTS = [
  { value: 'ejecutivo', label: 'Ejecutivo' },
  { value: 'administrador', label: 'Administrador' },
  { value: 'fundador', label: 'Fundador' },
]

const ROLE_COLORS: Record<string, string> = {
  fundador: 'bg-gold/20 text-gold',
  administrador: 'bg-blue-900/40 text-blue-400',
  ejecutivo: 'bg-emerald-900/40 text-emerald-400',
}

const fieldCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 appearance-none'
const labelCls = 'block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase'

export default function Executives() {
  const { profile: me } = useAuth()
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState<InviteForm>({ email: '', full_name: '', password: '', role: 'agente' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const canManage = me?.role === 'fundador'

  useEffect(() => { loadProfiles() }, [])

  async function loadProfiles() {
    setLoading(true)
    const { data } = await supabase.from('profiles').select('*').order('created_at')
    setProfiles(data || [])
    setLoading(false)
  }

  function openNew() {
    setEditId(null)
    setForm({ email: '', full_name: '', password: '', role: 'ejecutivo' })
    setError('')
    setShowForm(true)
  }

  function openEdit(p: Profile) {
    setEditId(p.id)
    setForm({ email: p.email || '', full_name: p.full_name, password: '', role: p.role })
    setError('')
    setShowForm(true)
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setError('')

    if (editId) {
      const update: Record<string, unknown> = {
        full_name: form.full_name, role: form.role, email: form.email,
        updated_at: new Date().toISOString(),
      }
      const { error: err } = await supabase.from('profiles').update(update).eq('id', editId)
      if (err) { setError(err.message); setSaving(false); return }
    } else {
      const { data, error: signUpErr } = await supabase.auth.admin
        ? { data: null, error: null }
        : await supabase.auth.signUp({
            email: form.email,
            password: form.password,
            options: { data: { full_name: form.full_name, role: form.role } },
          })
      if (signUpErr) { setError(signUpErr.message); setSaving(false); return }
      if (data?.user) {
        await supabase.from('profiles').update({ role: form.role, full_name: form.full_name }).eq('id', data.user.id)
      }
    }

    await loadProfiles()
    setShowForm(false)
    setSaving(false)
  }

  async function toggleActive(p: Profile) {
    await supabase.from('profiles').update({ is_active: !p.is_active }).eq('id', p.id)
    loadProfiles()
  }

  return (
    <div className="p-8">
      <div className="flex items-start justify-between gap-4 mb-8">
        <div>
          <h1 className="font-heading text-2xl font-bold text-white">Ejecutivos</h1>
          <p className="text-neutral-500 text-sm mt-1">Gestión de usuarios del equipo</p>
        </div>
        {canManage && (
          <button onClick={openNew} className="flex items-center gap-2 px-5 py-2.5 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors text-sm">
            <Plus className="w-4 h-4" /> Nuevo usuario
          </button>
        )}
      </div>

      {loading ? (
        <div className="space-y-2">{[1, 2, 3].map((i) => <div key={i} className="bg-[#141414] h-16 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="bg-[#141414] rounded-xl border border-gold/10 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#111] border-b border-gold/10">
                <th className="text-left px-5 py-3 font-medium text-neutral-500 text-xs">Nombre</th>
                <th className="text-left px-5 py-3 font-medium text-neutral-500 text-xs">Correo</th>
                <th className="text-left px-5 py-3 font-medium text-neutral-500 text-xs">Rol</th>
                <th className="text-left px-5 py-3 font-medium text-neutral-500 text-xs">Estado</th>
                {canManage && <th className="px-5 py-3" />}
              </tr>
            </thead>
            <tbody>
              {profiles.map((p) => (
                <tr key={p.id} className="border-b border-gold/5 hover:bg-[#1a1a1a]">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center shrink-0">
                        <Shield className="w-3.5 h-3.5 text-gold/60" />
                      </div>
                      <span className="text-white text-sm font-medium">{p.full_name}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-neutral-400 text-sm">{p.email || '—'}</td>
                  <td className="px-5 py-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-medium capitalize ${ROLE_COLORS[p.role] || 'text-neutral-400'}`}>{p.role}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`text-xs ${p.is_active ? 'text-emerald-400' : 'text-neutral-600'}`}>
                      {p.is_active ? 'Activo' : 'Inactivo'}
                    </span>
                  </td>
                  {canManage && (
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2 justify-end">
                        <button onClick={() => openEdit(p)} className="p-1.5 text-neutral-600 hover:text-gold transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                        {p.id !== me?.id && (
                          <button onClick={() => toggleActive(p)} className={`text-[10px] px-2 py-0.5 rounded transition-colors ${p.is_active ? 'bg-red-950/40 text-red-400 hover:bg-red-900/40' : 'bg-emerald-950/40 text-emerald-400'}`}>
                            {p.is_active ? 'Desactivar' : 'Activar'}
                          </button>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-50 px-4">
          <div className="bg-[#141414] border border-gold/15 rounded-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b border-gold/10">
              <h3 className="font-heading text-lg font-semibold text-white">{editId ? 'Editar usuario' : 'Nuevo usuario'}</h3>
              <button onClick={() => setShowForm(false)} className="text-neutral-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              {error && <div className="px-4 py-3 bg-red-950/40 border border-red-500/30 rounded-lg text-red-400 text-sm">{error}</div>}
              <div>
                <label className={labelCls}>Nombre completo *</label>
                <input required value={form.full_name} onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))} className={fieldCls} />
              </div>
              <div>
                <label className={labelCls}>Correo electrónico *</label>
                <input type="email" required value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} className={fieldCls} />
              </div>
              {!editId && (
                <div>
                  <label className={labelCls}>Contraseña *</label>
                  <input type="password" required minLength={8} value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder="Mínimo 8 caracteres" className={fieldCls} />
                </div>
              )}
              <div>
                <label className={labelCls}>Rol *</label>
                <select value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))} className={fieldCls}>
                  {ROLE_OPTS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="flex items-center gap-2 px-6 py-2.5 bg-gold text-black-brand font-semibold rounded-lg text-sm disabled:opacity-50">
                  <Check className="w-4 h-4" /> {saving ? 'Guardando...' : 'Guardar'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2.5 border border-gold/20 text-neutral-400 rounded-lg text-sm">Cancelar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
