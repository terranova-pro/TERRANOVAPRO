import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { Building2, Users, Eye, TrendingUp, Clock } from 'lucide-react'

interface Stats {
  total: number
  disponibles: number
  vendidas: number
  arrendadas: number
  contacts: number
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats>({ total: 0, disponibles: 0, vendidas: 0, arrendadas: 0, contacts: 0 })
  const [recent, setRecent] = useState<Array<{ id: string; title: string; status: string; created_at: string }>>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const [{ data: props }, { data: contacts }, { data: recentProps }] = await Promise.all([
        supabase.from('properties').select('status'),
        supabase.from('contacts').select('id'),
        supabase.from('properties').select('id, title, status, created_at').order('created_at', { ascending: false }).limit(5),
      ])
      const all = props || []
      setStats({
        total: all.length,
        disponibles: all.filter((p) => p.status === 'disponible').length,
        vendidas: all.filter((p) => p.status === 'vendida').length,
        arrendadas: all.filter((p) => p.status === 'arrendada').length,
        contacts: contacts?.length || 0,
      })
      setRecent(recentProps || [])
      setLoading(false)
    }
    load()
  }, [])

  const STATUS_COLORS: Record<string, string> = {
    disponible: 'text-emerald-400', reservada: 'text-amber-400',
    vendida: 'text-blue-400', arrendada: 'text-neutral-400',
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="font-heading text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-neutral-500 text-sm mt-1">Resumen general del sistema</p>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => <div key={i} className="h-28 bg-[#191919] rounded-xl border border-gold/10 animate-pulse" />)}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Propiedades', value: stats.total, icon: Building2, color: 'text-gold', bg: 'bg-gold/10' },
              { label: 'Disponibles', value: stats.disponibles, icon: TrendingUp, color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
              { label: 'Vendidas', value: stats.vendidas, icon: Eye, color: 'text-blue-400', bg: 'bg-blue-400/10' },
              { label: 'Contactos CRM', value: stats.contacts, icon: Users, color: 'text-purple-400', bg: 'bg-purple-400/10' },
            ].map(({ label, value, icon: Icon, color, bg }) => (
              <div key={label} className="bg-[#141414] border border-gold/10 rounded-xl p-5">
                <div className={`w-10 h-10 rounded-lg ${bg} flex items-center justify-center mb-4`}>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <p className="text-2xl font-bold text-white">{value}</p>
                <p className="text-neutral-500 text-sm mt-0.5">{label}</p>
              </div>
            ))}
          </div>

          <div className="bg-[#141414] border border-gold/10 rounded-xl p-6">
            <div className="flex items-center gap-2 mb-5">
              <Clock className="w-4 h-4 text-gold" />
              <h2 className="text-white font-semibold text-sm">Propiedades recientes</h2>
            </div>
            <div className="space-y-3">
              {recent.map((p) => (
                <div key={p.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <p className="text-neutral-300 text-sm truncate max-w-[70%]">{p.title}</p>
                  <span className={`text-xs font-medium capitalize ${STATUS_COLORS[p.status] || 'text-neutral-400'}`}>
                    {p.status}
                  </span>
                </div>
              ))}
              {recent.length === 0 && <p className="text-neutral-600 text-sm">No hay propiedades aún.</p>}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
