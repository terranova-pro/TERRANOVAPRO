import { Link } from 'react-router-dom'
import { TrendingUp, BarChart3, PieChart, Building2, MapPin, ArrowRight, CheckCircle } from 'lucide-react'
import SectionHeading from '../components/SectionHeading'

export default function Investments() {
  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <TrendingUp className="w-12 h-12 text-gold mx-auto mb-5" />
          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white">
            <span className="text-gold">Inversiones</span> Inmobiliarias
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Asesoría personalizada para construir un portafolio inmobiliario rentable en Chile.
          </p>
        </div>
      </section>

      <section className="py-24 bg-[#141414] border-b border-gold/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Oportunidades de inversión" subtitle="Diversifica tu portafolio con activos inmobiliarios" light center />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            {[
              { icon: Building2, title: 'Departamentos', desc: 'Alta demanda en zonas oriente de Santiago. Renta estable y plusvalía sostenida.', roi: '5–7% anual' },
              { icon: MapPin, title: 'Terrenos', desc: 'Plusvalía acelerada en zonas de expansión urbana. Ideal para largo plazo.', roi: '15–40% en 5 años' },
              { icon: PieChart, title: 'Fondos Inmobiliarios', desc: 'Inversión fraccionada en proyectos de alto impacto con gestión profesional.', roi: '8–12% anual' },
            ].map((inv) => (
              <div key={inv.title} className="bg-[#191919] p-8 rounded-xl border border-gold/10 hover:border-gold/30 transition-all">
                <inv.icon className="w-10 h-10 text-gold mb-5" />
                <h3 className="font-heading text-xl font-semibold text-white">{inv.title}</h3>
                <p className="mt-3 text-sm text-neutral-500 leading-relaxed">{inv.desc}</p>
                <div className="mt-5 pt-4 border-t border-gold/10">
                  <span className="text-xs text-neutral-600 tracking-wider uppercase">Retorno esperado</span>
                  <div className="text-xl font-bold text-gold mt-1">{inv.roi}</div>
                </div>
              </div>
            ))}
          </div>

          <SectionHeading title="Proceso de inversión" subtitle="Te acompañamos de principio a fin" light center />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
            {[
              { step: '01', title: 'Perfilamiento', desc: 'Analizamos tu perfil de riesgo, horizonte de inversión y objetivos financieros.' },
              { step: '02', title: 'Selección', desc: 'Identificamos oportunidades que se ajusten a tu estrategia y presupuesto.' },
              { step: '03', title: 'Due Diligence', desc: 'Verificación legal, técnica y financiera completa del activo inmobiliario.' },
              { step: '04', title: 'Cierre y Gestión', desc: 'Acompañamiento en la adquisición y gestión continua de tu inversión.' },
            ].map((s) => (
              <div key={s.step} className="flex gap-5">
                <div className="w-12 h-12 bg-gold/10 rounded-lg flex items-center justify-center shrink-0">
                  <span className="font-heading text-lg font-bold text-gold">{s.step}</span>
                </div>
                <div>
                  <h3 className="font-heading text-xl font-semibold text-white">{s.title}</h3>
                  <p className="mt-2 text-sm text-neutral-500 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-[#191919] rounded-2xl p-8 sm:p-10 border border-gold/10 mb-12">
            <h3 className="font-heading text-2xl font-bold text-white mb-6 text-center">Ventajas de invertir con Terranova</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                'Análisis de mercado con datos actualizados',
                'Acceso exclusivo a oportunidades off-market',
                'Red de abogados y notarios especializados',
                'Gestión de propiedades post-inversión',
                'Reportes trimestrales de rendimiento',
                'Asesoría tributaria para optimización',
              ].map((b) => (
                <div key={b} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-gold shrink-0" />
                  <span className="text-sm text-neutral-400">{b}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border border-gold/20 rounded-2xl p-10 sm:p-14 text-center">
            <BarChart3 className="w-10 h-10 text-gold mx-auto mb-5" />
            <h3 className="font-heading text-2xl font-bold text-white mb-4">Agenda una asesoría gratuita</h3>
            <p className="text-neutral-500 mb-8 max-w-lg mx-auto leading-relaxed">
              Nuestro equipo de análisis te ayudará a identificar la mejor estrategia de inversión para tus objetivos.
            </p>
            <Link to="/contacto"
              className="px-10 py-4 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors inline-flex items-center gap-2 text-sm tracking-wide">
              Agendar asesoría <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
