import { useState } from 'react'
import { CheckCircle, TreePine } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { REGIONS, COMUNAS_BY_REGION } from '../data/chile'

const TERRAIN_TYPES = [
  { value: 'urbano', label: 'Urbano' },
  { value: 'rural', label: 'Rural' },
  { value: 'agricola', label: 'Agrícola' },
  { value: 'industrial', label: 'Industrial' },
  { value: 'residencial', label: 'Residencial' },
]

export default function SellTerrain() {
  const [form, setForm] = useState({
    owner_name: '', owner_email: '', owner_phone: '', owner_rut: '',
    address: '', region: '', comuna: '', terrain_type: '',
    m2_terreno: '', asking_price: '', description: '',
    has_title: false, has_plan: false, has_permits: false,
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const comunas = form.region ? COMUNAS_BY_REGION[form.region] || [] : []

  function update(key: string, value: string | boolean) {
    const next = { ...form, [key]: value }
    if (key === 'region') next.comuna = ''
    setForm(next)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await supabase.from('property_submissions').insert({
      owner_name: form.owner_name,
      owner_email: form.owner_email,
      owner_phone: form.owner_phone,
      owner_rut: form.owner_rut || null,
      property_type: 'terreno',
      listing_type: 'venta',
      address: form.address,
      region: form.region,
      comuna: form.comuna,
      m2_terreno: form.m2_terreno ? Number(form.m2_terreno) : null,
      asking_price: form.asking_price ? Number(form.asking_price) : null,
      description: form.description || null,
      has_title: form.has_title,
      has_plan: form.has_plan,
      has_permits: form.has_permits,
      is_terreno: true,
      terrain_type: form.terrain_type || null,
      status: 'pendiente',
    })
    setSubmitted(true)
    setLoading(false)
  }

  const fieldCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 placeholder:text-neutral-600 focus:outline-none focus:border-gold/50 appearance-none'

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <TreePine className="w-12 h-12 text-gold mx-auto mb-5" />
          <h1 className="font-heading text-4xl sm:text-5xl font-bold text-white">
            Vende tu <span className="text-gold">terreno</span>
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Especialistas en comercialización de terrenos urbanos, rurales y agrícolas en todo Chile.
          </p>
        </div>
      </section>

      <section className="py-24 bg-[#141414]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-16">
            {[
              { title: 'Plusvalía Garantizada', desc: 'Asesoramos en pricing para maximizar el retorno de tu inversión en terreno.' },
              { title: 'Estudios de Factibilidad', desc: 'Verificamos servicios, planificación y potencial de desarrollo del terreno.' },
              { title: 'Red de Compradores', desc: 'Acceso a base de inversionistas y desarrolladores inmobiliarios activos.' },
              { title: 'Documentación Legal', desc: 'Revisión de escrituras, certificados y permisos para cierre seguro.' },
            ].map((b) => (
              <div key={b.title} className="bg-[#191919] p-8 rounded-xl border border-gold/10">
                <CheckCircle className="w-6 h-6 text-gold mb-3" />
                <h3 className="font-heading text-base font-semibold text-white">{b.title}</h3>
                <p className="mt-2 text-sm text-neutral-500 leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>

          {submitted ? (
            <div className="text-center py-16 bg-[#191919] rounded-2xl border border-gold/15">
              <CheckCircle className="w-16 h-16 text-gold mx-auto mb-4" />
              <h3 className="font-heading text-2xl font-bold text-white">Solicitud recibida</h3>
              <p className="mt-3 text-neutral-500 max-w-md mx-auto leading-relaxed">
                Evaluaremos tu terreno y te contactaremos para iniciar el proceso de comercialización.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-[#191919] rounded-2xl p-6 sm:p-8 border border-gold/10">
              <h3 className="font-heading text-xl font-semibold text-white mb-6">Datos del propietario</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                <input required placeholder="Nombre completo" value={form.owner_name} onChange={(e) => update('owner_name', e.target.value)} className={fieldCls} />
                <input required type="email" placeholder="Email" value={form.owner_email} onChange={(e) => update('owner_email', e.target.value)} className={fieldCls} />
                <input required placeholder="Teléfono" value={form.owner_phone} onChange={(e) => update('owner_phone', e.target.value)} className={fieldCls} />
                <input placeholder="RUT" value={form.owner_rut} onChange={(e) => update('owner_rut', e.target.value)} className={fieldCls} />
              </div>

              <h3 className="font-heading text-xl font-semibold text-white mb-6">Datos del terreno</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <select required value={form.terrain_type} onChange={(e) => update('terrain_type', e.target.value)} className={fieldCls}>
                  <option value="">Tipo de terreno</option>
                  {TERRAIN_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
                <select required value={form.region} onChange={(e) => update('region', e.target.value)} className={fieldCls}>
                  <option value="">Región</option>
                  {REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
                <select required value={form.comuna} onChange={(e) => update('comuna', e.target.value)} className={fieldCls} disabled={!comunas.length}>
                  <option value="">Comuna</option>
                  {comunas.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <input required placeholder="Dirección o ubicación" value={form.address} onChange={(e) => update('address', e.target.value)} className={`${fieldCls} sm:col-span-2`} />
                <input type="number" placeholder="Superficie (m²)" value={form.m2_terreno} onChange={(e) => update('m2_terreno', e.target.value)} className={fieldCls} />
                <input type="number" placeholder="Precio solicitado (CLP)" value={form.asking_price} onChange={(e) => update('asking_price', e.target.value)} className={fieldCls} />
              </div>

              <textarea placeholder="Descripción del terreno, servicios disponibles, accesos, etc." rows={4} value={form.description} onChange={(e) => update('description', e.target.value)} className={`${fieldCls} resize-none mb-6`} />

              <div className="flex flex-wrap gap-6 mb-8">
                {[
                  { key: 'has_title', label: 'Tiene escritura' },
                  { key: 'has_plan', label: 'Tiene planos' },
                  { key: 'has_permits', label: 'Tiene factibilidades / permisos' },
                ].map((c) => (
                  <label key={c.key} className="flex items-center gap-2 cursor-pointer text-sm text-neutral-400">
                    <input type="checkbox" checked={form[c.key as keyof typeof form] as boolean} onChange={(e) => update(c.key, e.target.checked)} className="accent-gold w-4 h-4" />
                    {c.label}
                  </label>
                ))}
              </div>

              <button type="submit" disabled={loading} className="w-full sm:w-auto px-10 py-3 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-dark transition-colors disabled:opacity-50">
                {loading ? 'Enviando...' : 'Enviar solicitud'}
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  )
}
