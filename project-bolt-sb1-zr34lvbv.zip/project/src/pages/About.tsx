import { Link } from 'react-router-dom'
import { Shield, Users, Target, Award, ArrowRight } from 'lucide-react'
import SectionHeading from '../components/SectionHeading'

export default function About() {
  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white">
            Sobre <span className="text-gold">Terranova</span>
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Más de una década de excelencia en el mercado inmobiliario chileno.
          </p>
        </div>
      </section>

      <section className="py-24 bg-[#141414] border-b border-gold/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <SectionHeading title="Nuestra misión" subtitle="Transformar la experiencia inmobiliaria en Chile" light />
              <p className="text-neutral-400 leading-relaxed mb-6">
                En Terranova Propiedades creemos que comprar, vender o arrendar una propiedad debe ser una experiencia transparente, eficiente y profesional. Nuestra plataforma integra tecnología de punta con conocimiento profundo del mercado chileno.
              </p>
              <p className="text-neutral-500 leading-relaxed">
                Nos diferenciamos por nuestra integración multi-portal: una sola publicación alcanza todos los portales inmobiliarios relevantes de Chile, eliminando la doble carga de trabajo y acelerando los tiempos de gestión.
              </p>
            </div>
            <div className="relative">
              <img src="https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg" alt="Terranova" className="rounded-xl w-full object-cover aspect-[4/3] opacity-80" />
              <div className="absolute -bottom-4 -left-4 bg-gold text-black-brand px-6 py-3 rounded-lg shadow-2xl">
                <span className="font-heading text-2xl font-bold">10+</span>
                <span className="text-sm ml-2 font-body">años de experiencia</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-black-brand border-b border-gold/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Nuestros valores" light center />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: 'Transparencia', desc: 'Procesos claros, comisiones justas y comunicación constante con nuestros clientes.' },
              { icon: Target, title: 'Eficiencia', desc: 'Automatización e integración que reducen tiempos y maximizan resultados.' },
              { icon: Users, title: 'Compromiso', desc: 'Cada cliente recibe atención personalizada y dedicación exclusiva.' },
              { icon: Award, title: 'Excelencia', desc: 'Estándares premium en cada propiedad, desde la fotografía hasta el cierre.' },
            ].map((v) => (
              <div key={v.title} className="text-center p-8 bg-[#191919] rounded-xl border border-gold/10">
                <v.icon className="w-10 h-10 text-gold mx-auto mb-4" />
                <h3 className="font-heading text-xl font-semibold text-white">{v.title}</h3>
                <p className="mt-3 text-sm text-neutral-500 leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#141414]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="font-heading text-3xl font-bold text-white mb-5">Integración con portales inmobiliarios</h3>
          <p className="text-neutral-500 max-w-2xl mx-auto mb-10 leading-relaxed">
            Terranova integra directamente con Portal Inmobiliario, Propiedades Chile e Yapo. Una sola carga de datos publica tu propiedad en todos los portales simultáneamente.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {['Portal Inmobiliario', 'Propiedades Chile', 'Yapo'].map((portal) => (
              <span key={portal} className="px-5 py-2.5 border border-gold/25 rounded-lg text-gold/80 text-sm">
                {portal}
              </span>
            ))}
          </div>
          <Link to="/contacto"
            className="px-10 py-4 bg-gold text-black-brand font-semibold rounded-lg hover:bg-gold-light transition-colors inline-flex items-center gap-2 text-sm tracking-wide">
            Conocer más <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </div>
  )
}
