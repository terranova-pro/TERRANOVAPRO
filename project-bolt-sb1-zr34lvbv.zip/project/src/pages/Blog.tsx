import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Calendar, ArrowRight, Tag } from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { BlogPost } from '../types'
import SectionHeading from '../components/SectionHeading'

const CATEGORY_LABELS: Record<string, string> = {
  noticias: 'Noticias',
  consejos: 'Consejos',
  mercado: 'Mercado',
  inversiones: 'Inversiones',
  legislacion: 'Legislación',
}

const darkInput = 'bg-[#1c1c1c] border border-gold/20 text-neutral-300'

export default function Blog() {
  const [posts, setPosts] = useState<BlogPost[]>([])
  const [filter, setFilter] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadPosts()
  }, [filter])

  async function loadPosts() {
    setLoading(true)
    let query = supabase.from('blog_posts').select('*').eq('published', true)
    if (filter) query = query.eq('category', filter)
    const { data } = await query.order('published_at', { ascending: false })
    setPosts(data || [])
    setLoading(false)
  }

  return (
    <div className="pt-20 bg-black-brand min-h-screen">
      <section className="py-20 border-b border-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white">
            <span className="text-gold">Blog</span> Inmobiliario
          </h1>
          <p className="mt-5 text-neutral-500 max-w-xl mx-auto leading-relaxed">
            Noticias, análisis y consejos del mercado inmobiliario chileno.
          </p>
        </div>
      </section>

      <section className="py-14 bg-[#141414]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-2 mb-10">
            <button
              onClick={() => setFilter('')}
              className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-wide uppercase transition-colors ${!filter ? 'bg-gold text-black-brand' : 'bg-[#1c1c1c] text-neutral-500 border border-gold/15 hover:border-gold/35 hover:text-neutral-300'}`}
            >
              Todos
            </button>
            {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-wide uppercase transition-colors ${filter === key ? 'bg-gold text-black-brand' : 'bg-[#1c1c1c] text-neutral-500 border border-gold/15 hover:border-gold/35 hover:text-neutral-300'}`}
              >
                {label}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="rounded-xl overflow-hidden bg-[#191919]">
                  <div className="aspect-[16/9] animate-shimmer" />
                  <div className="p-5 space-y-3">
                    <div className="h-5 w-3/4 animate-shimmer rounded" />
                    <div className="h-4 w-full animate-shimmer rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : posts.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-neutral-600">No hay artículos disponibles en esta categoría.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.map((post) => (
                <Link
                  key={post.id}
                  to={`/blog/${post.slug}`}
                  className="group bg-[#191919] rounded-xl overflow-hidden border border-gold/10 hover:border-gold/30 hover:shadow-2xl hover:shadow-black/60 transition-all"
                >
                  {post.image_url ? (
                    <div className="aspect-[16/9] overflow-hidden">
                      <img src={post.image_url} alt={post.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" />
                    </div>
                  ) : (
                    <div className="aspect-[16/9] bg-[#222] flex items-center justify-center">
                      <Tag className="w-8 h-8 text-neutral-600" />
                    </div>
                  )}
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs px-2.5 py-0.5 bg-gold/10 text-gold rounded font-medium tracking-wide">
                        {CATEGORY_LABELS[post.category]}
                      </span>
                      {post.published_at && (
                        <span className="text-xs text-neutral-600 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(post.published_at).toLocaleDateString('es-CL')}
                        </span>
                      )}
                    </div>
                    <h3 className="font-heading text-lg font-semibold text-white group-hover:text-gold transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    {post.excerpt && (
                      <p className="mt-2 text-sm text-neutral-500 line-clamp-2">{post.excerpt}</p>
                    )}
                    <span className="mt-3 inline-flex items-center gap-1 text-xs text-gold font-medium">
                      Leer más <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
