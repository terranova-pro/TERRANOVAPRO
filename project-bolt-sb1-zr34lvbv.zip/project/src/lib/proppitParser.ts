import type { Property, PropertyType, ListingType } from '../types'

function decodeHtml(str: string) {
  return str.replace(/&#\d+;/g, '').trim()
}

function parsePrice(raw: string): { price: number | null; currency: 'CLP' | 'UF' } {
  const cleaned = raw.replace(/\./g, '').replace(/\s/g, '')
  const ufMatch = cleaned.match(/^([\d,]+)UF$/i)
  if (ufMatch) return { price: parseFloat(ufMatch[1].replace(',', '.')), currency: 'UF' }
  const clpMatch = cleaned.match(/^([\d]+)\$?$/)
  if (clpMatch) return { price: parseInt(clpMatch[1], 10), currency: 'CLP' }
  return { price: null, currency: 'CLP' }
}

function parseSurface(raw: string): number | null {
  const m = raw.replace(/\s/g, '').match(/^([\d.]+)m2?$/i)
  return m ? parseFloat(m[1]) : null
}

function mapPropertyType(raw: string): PropertyType {
  const map: Record<string, PropertyType> = {
    departamento: 'departamento', casa: 'casa', terreno: 'terreno',
    oficina: 'oficina', local: 'comercial', comercial: 'comercial',
    bodega: 'bodega', estacionamiento: 'estacionamiento',
  }
  return map[raw.toLowerCase()] ?? 'departamento'
}

function mapListingType(raw: string): ListingType {
  const lower = raw.toLowerCase()
  if (lower.includes('arriendo')) return 'arriendo'
  if (lower.includes('venta')) return 'venta'
  return 'venta'
}

function parseCSVLine(line: string): string[] {
  const result: string[] = []
  let current = ''
  let inQuotes = false
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]
    if (ch === '"') {
      inQuotes = !inQuotes
    } else if (ch === ';' && !inQuotes) {
      result.push(current.trim())
      current = ''
    } else {
      current += ch
    }
  }
  result.push(current.trim())
  return result
}

export interface ParsedListing {
  proppit_ref: string
  title: string
  description: string
  property_type: PropertyType
  listing_type: ListingType
  price: number | null
  currency: 'CLP' | 'UF'
  address: string
  region: string
  comuna: string
  m2_util: number | null
  m2_terreno: number | null
  dormitorios: number | null
  banos: number | null
  estacionamientos: number
  featured: boolean
  status: 'disponible'
  images: string[]
  portal_ids: Record<string, string>
  owner_email: string | null
  owner_phone: string | null
}

export function parseProppitCSV(csvText: string): ParsedListing[] {
  const lines = csvText.split('\n').filter((l) => l.trim())
  if (lines.length < 2) return []

  // Build header index
  const headers = parseCSVLine(lines[0]).map((h) => h.replace(/"/g, '').trim().toLowerCase())
  const idx = (name: string) => headers.findIndex((h) => h.includes(name))

  const iRef = idx('referencia')
  const iTitle = idx('título')
  const iDesc = idx('descripción')
  const iCity = idx('ciudad')
  const iPropType = idx('tipo de propiedad')
  const iListType = idx('tipo de operación')
  const iPrice = idx('precio')
  const iDorm = idx('dormitorios')
  const iBanos = idx('baños')
  const iUtil = idx('superficie útil')
  const iTotal = idx('superficie total')
  const iTerr = idx('superficie del terreno')
  const iEmail = idx('email')
  const iPhone = idx('teléfono')
  const iIcasas = idx('link icasas')
  const iTrovit = idx('link trovit')

  const results: ParsedListing[] = []

  for (let i = 1; i < lines.length; i++) {
    const cols = parseCSVLine(lines[i])
    if (cols.length < 5) continue

    const ref = decodeHtml(cols[iRef] ?? '')
    if (!ref) continue

    const rawPrice = cols[iPrice] ?? ''
    const { price, currency } = parsePrice(rawPrice)

    const rawCity = (cols[iCity] ?? '').replace(/"/g, '').trim()
    // Extract comuna from city string like "San Martín 870, Santiago, Chile"
    const parts = rawCity.split(',')
    const address = rawCity
    const comuna = parts.length >= 2 ? parts[parts.length - 2].trim() : parts[0].trim()
    const region = 'Región Metropolitana de Santiago'

    const rawUtil = cols[iUtil] ?? ''
    const rawTotal = cols[iTotal] ?? ''
    const rawTerr = cols[iTerr] ?? ''
    const m2_util = parseSurface(rawUtil) ?? parseSurface(rawTotal)
    const m2_terreno = parseSurface(rawTerr) ?? parseSurface(rawTotal)

    const dormitorios = parseInt(cols[iDorm] ?? '', 10) || null
    const banos = parseInt(cols[iBanos] ?? '', 10) || null

    const portalIds: Record<string, string> = {}
    const icasasUrl = cols[iIcasas] ?? ''
    const trovitUrl = cols[iTrovit] ?? ''
    if (icasasUrl) {
      const m = icasasUrl.match(/re\/([a-z0-9-]+)/i)
      if (m) portalIds.icasas = m[1]
    }
    if (trovitUrl) portalIds.trovit_url = trovitUrl

    results.push({
      proppit_ref: ref,
      title: (cols[iTitle] ?? '').replace(/"/g, '').trim(),
      description: (cols[iDesc] ?? '').replace(/"/g, '').trim(),
      property_type: mapPropertyType((cols[iPropType] ?? '').replace(/"/g, '')),
      listing_type: mapListingType((cols[iListType] ?? '').replace(/"/g, '')),
      price,
      currency,
      address,
      region,
      comuna,
      m2_util,
      m2_terreno,
      dormitorios,
      banos,
      estacionamientos: 0,
      featured: false,
      status: 'disponible',
      images: [],
      portal_ids: portalIds,
      owner_email: decodeHtml(cols[iEmail] ?? '') || null,
      owner_phone: decodeHtml(cols[iPhone] ?? '') || null,
    })
  }

  return results
}
