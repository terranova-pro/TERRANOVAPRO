import { Link } from 'react-router-dom'
import { MapPin, Bed, Bath, Car, Maximize2, Building2 } from 'lucide-react'
import type { Property } from '../types'

const LISTING_LABELS: Record<string, string> = {
  venta: 'Venta',
  arriendo: 'Arriendo',
  arriendo_diario: 'Arriendo Diario',
  arriendo_temporada: 'Arriendo Temporada',
}

const LISTING_COLORS: Record<string, string> = {
  venta: 'bg-gold text-black-brand',
  arriendo: 'bg-[#1c1c1c] text-gold border border-gold/30',
  arriendo_diario: 'bg-[#222] text-gold border border-gold/20',
  arriendo_temporada: 'bg-gold-dark text-white',
}

export function formatPrice(price: number | null, currency: string, listingType: string) {
  if (!price) return 'Precio a consultar'
  if (currency === 'UF') return `${price.toLocaleString('es-CL')} UF`
  const formatted = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(price)
  const suffix = listingType === 'arriendo' ? '/mes' : listingType === 'arriendo_diario' ? '/día' : listingType === 'arriendo_temporada' ? '/temporada' : ''
  return `${formatted}${suffix}`
}

const STATUS_WATERMARK: Record<string, string> = {
  vendida: 'VENDIDA',
  arrendada: 'ARRENDADA',
}

export default function PropertyCard({ property }: { property: Property }) {
  const image = property.images?.[0] ?? null
  const watermark = STATUS_WATERMARK[property.status]

  return (
    <Link
      to={`/propiedad/${property.id}`}
      className="group bg-[#191919] rounded-xl overflow-hidden border border-gold/10 hover:border-gold/35 hover:shadow-2xl hover:shadow-black/60 transition-all duration-300"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-[#141414]">
        {image ? (
          <img
            src={image}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-85 group-hover:opacity-100"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-3">
            <Building2 className="w-10 h-10 text-gold/20" />
            <span className="text-neutral-700 text-[10px] tracking-widest uppercase font-medium">Sin fotografía</span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
        {watermark && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className="text-white/80 text-3xl sm:text-4xl font-bold tracking-[0.15em] -rotate-12 border-4 border-white/60 px-6 py-2 rounded-md bg-black/40 select-none">
              {watermark}
            </span>
          </div>
        )}
        <div className="absolute top-3 left-3 flex gap-2">
          <span className={`px-3 py-1 text-xs font-semibold rounded ${LISTING_COLORS[property.listing_type] || 'bg-gold text-black-brand'}`}>
            {LISTING_LABELS[property.listing_type]}
          </span>
          {property.featured && (
            <span className="px-3 py-1 text-xs font-semibold rounded bg-black/70 text-gold border border-gold/30">
              Destacada
            </span>
          )}
        </div>
      </div>

      <div className="p-5">
        <h3 className="font-heading text-lg font-semibold text-white group-hover:text-gold transition-colors line-clamp-1">
          {property.title}
        </h3>
        <div className="flex items-center gap-1.5 mt-2 text-neutral-500 text-xs">
          <MapPin className="w-3.5 h-3.5 text-gold/60 shrink-0" />
          <span className="line-clamp-1">{property.comuna}, {property.region}</span>
        </div>

        <div className="flex flex-wrap gap-3 mt-4 text-xs text-neutral-500">
          {property.dormitorios != null && property.dormitorios > 0 && (
            <span className="flex items-center gap-1"><Bed className="w-3.5 h-3.5 text-gold/60" /> {property.dormitorios}</span>
          )}
          {property.banos != null && property.banos > 0 && (
            <span className="flex items-center gap-1"><Bath className="w-3.5 h-3.5 text-gold/60" /> {property.banos}</span>
          )}
          {property.m2_util != null && property.m2_util > 0 && (
            <span className="flex items-center gap-1"><Maximize2 className="w-3.5 h-3.5 text-gold/60" /> {property.m2_util} m²</span>
          )}
          {property.estacionamientos > 0 && (
            <span className="flex items-center gap-1"><Car className="w-3.5 h-3.5 text-gold/60" /> {property.estacionamientos}</span>
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-gold/10">
          <span className="font-heading text-xl font-bold text-gold">
            {formatPrice(property.price, property.currency, property.listing_type)}
          </span>
          {property.m2_terreno != null && property.m2_terreno > 0 && (
            <span className="block text-xs text-neutral-600 mt-1">
              Terreno: {property.m2_terreno.toLocaleString()} m²
            </span>
          )}
        </div>
      </div>
    </Link>
  )
}
