import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, ChevronDown, Lock } from 'lucide-react'

const NAV_ITEMS = [
  { label: 'Inicio', path: '/' },
  { label: 'Nosotros', path: '/nosotros' },
  { label: 'Propiedades', path: '/propiedades' },
  {
    label: 'Servicios',
    children: [
      { label: 'Vende con Terranova', path: '/vende-con-terranova' },
      { label: 'Vende tu Terreno', path: '/vende-tu-terreno' },
      { label: 'Administración', path: '/administracion' },
      { label: 'Inversiones', path: '/inversiones' },
    ],
  },
  { label: 'Blog', path: '/blog' },
  { label: 'Contacto', path: '/contacto' },
]

// Margen lateral de la página: 8% cada lado
const PAGE_MARGIN = 'px-[8%]'

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setOpen(false)
    setDropdownOpen(false)
  }, [location])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
        scrolled
          ? 'bg-black-brand/98 backdrop-blur-md shadow-xl shadow-black/30 border-b border-gold/10'
          : 'bg-transparent'
      }`}
    >
      {/* Full-width container: Intranet link stays outside page margins */}
      <div className="w-full px-0">
        <div className={`flex items-center h-16 lg:h-20`}>

          {/* Desktop nav — mismo ancho que logo TERRANOVA */}
          <div className="hidden lg:flex flex-1 items-center justify-center">
            <div className="flex items-center justify-between" style={{ width: 'clamp(320px, 58vw, 640px)' }}>
            {NAV_ITEMS.map((item) =>
              item.children ? (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() => setDropdownOpen(true)}
                  onMouseLeave={() => setDropdownOpen(false)}
                >
                  <button
                    className={`flex items-center gap-1 py-2 text-xs font-medium tracking-wider uppercase font-body transition-colors ${
                      item.children.some((c) => c.path === location.pathname)
                        ? 'text-gold'
                        : 'text-white/75 hover:text-gold'
                    }`}
                  >
                    {item.label}
                    <ChevronDown className={`w-3 h-3 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {dropdownOpen && (
                    <div className="absolute top-full left-0 bg-black-brand border border-gold/20 rounded-lg shadow-2xl py-2 min-w-[240px] animate-fade-in">
                      {item.children.map((child) => (
                        <Link
                          key={child.path}
                          to={child.path}
                          className={`block px-5 py-3 text-xs tracking-wide uppercase font-body transition-colors ${
                            location.pathname === child.path
                              ? 'text-gold bg-gold/5'
                              : 'text-white/65 hover:text-gold hover:bg-white/5'
                          }`}
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`py-2 text-xs font-medium tracking-wider uppercase font-body transition-colors ${
                    location.pathname === item.path
                      ? 'text-gold'
                      : 'text-white/75 hover:text-gold'
                  }`}
                >
                  {item.label}
                </Link>
              )
            )}
            </div>
          </div>

          {/* INTRANET — pegado al borde derecho */}
          <Link
            to="/intranet/login"
            className="hidden lg:flex items-center gap-1.5 px-4 py-2 text-[13px] font-semibold tracking-[0.2em] uppercase font-body text-gold/60 hover:text-gold border-l border-gold/10 h-full transition-colors"
          >
            <Lock className="w-3 h-3" />
            Intranet
          </Link>

          {/* Mobile: hamburger */}
          <div className="lg:hidden flex items-center justify-between w-full px-4">
            <div />
            <div className="flex items-center gap-3">
              <Link
                to="/intranet/login"
                className="flex items-center gap-1 text-[13px] tracking-widest uppercase text-gold/50 hover:text-gold transition-colors"
              >
                <Lock className="w-3 h-3" />
                Intranet
              </Link>
              <button
                className="text-white p-2"
                onClick={() => setOpen(!open)}
                aria-label="Toggle menu"
              >
                {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden bg-black-brand/99 backdrop-blur-md border-t border-gold/10 animate-fade-in">
          <div className="px-[8%] py-6 space-y-1">
            {NAV_ITEMS.map((item) =>
              item.children ? (
                <div key={item.label}>
                  <div className="px-3 py-2 text-[10px] uppercase tracking-[0.3em] text-gold/60 font-semibold font-body">
                    {item.label}
                  </div>
                  {item.children.map((child) => (
                    <Link
                      key={child.path}
                      to={child.path}
                      className={`block px-3 py-3 pl-7 text-xs tracking-wide uppercase font-body ${
                        location.pathname === child.path
                          ? 'text-gold'
                          : 'text-white/65 hover:text-gold'
                      }`}
                    >
                      {child.label}
                    </Link>
                  ))}
                </div>
              ) : (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`block px-3 py-3 text-xs tracking-wide uppercase font-body ${
                    location.pathname === item.path
                      ? 'text-gold'
                      : 'text-white/65 hover:text-gold'
                  }`}
                >
                  {item.label}
                </Link>
              )
            )}
          </div>
        </div>
      )}
    </nav>
  )
}
