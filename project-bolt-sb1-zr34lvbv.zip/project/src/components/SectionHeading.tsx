interface Props {
  title: string
  subtitle?: string
  light?: boolean
  center?: boolean
}

export default function SectionHeading({ title, subtitle, light, center }: Props) {
  return (
    <div className={`mb-12 ${center ? 'text-center' : ''}`}>
      <h2
        className={`font-heading text-3xl sm:text-4xl lg:text-5xl font-bold ${light ? 'text-white' : 'text-black-brand'}`}
      >
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-3 text-sm ${light ? 'text-white/55' : 'text-neutral-400'} tracking-wide leading-relaxed`}
          style={{ fontFamily: "'Montserrat', sans-serif" }}>
          {subtitle}
        </p>
      )}
      <div className={`mt-5 h-0.5 w-16 ${center ? 'mx-auto' : ''} bg-gold`} />
    </div>
  )
}
