import { MessageCircle } from 'lucide-react'
import { WHATSAPP_NUMBER } from '../data/chile'

export default function WhatsAppButton() {
  const message = encodeURIComponent('Hola, me interesa conocer más sobre las propiedades de Terranova.')
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg shadow-[#25D366]/30 hover:scale-110 transition-transform"
      aria-label="Contactar por WhatsApp"
    >
      <MessageCircle className="w-6 h-6 text-white" />
    </a>
  )
}
