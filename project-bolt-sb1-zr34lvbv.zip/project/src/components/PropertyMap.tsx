import { useEffect, useRef } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'
import { Link } from 'react-router-dom'
import type { Property } from '../types'
import { formatPrice } from './PropertyCard'

const goldIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
})

function FitBounds({ properties }: { properties: Property[] }) {
  const map = useMap()
  const prevCount = useRef(0)

  useEffect(() => {
    const withCoords = properties.filter((p) => p.latitude && p.longitude)
    if (withCoords.length === 0) return
    if (withCoords.length === prevCount.current) return
    prevCount.current = withCoords.length

    const bounds = L.latLngBounds(withCoords.map((p) => [p.latitude!, p.longitude!] as [number, number]))
    map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 })
  }, [properties, map])

  return null
}

interface Props {
  properties: Property[]
  height?: string
}

export default function PropertyMap({ properties, height = '500px' }: Props) {
  const withCoords = properties.filter((p) => p.latitude && p.longitude)
  const center: [number, number] = withCoords.length > 0
    ? [withCoords[0].latitude!, withCoords[0].longitude!]
    : [-33.45, -70.67]

  return (
    <div style={{ height }} className="rounded-lg overflow-hidden border border-neutral-200">
      <MapContainer center={center} zoom={10} scrollWheelZoom className="h-full w-full z-0">
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <FitBounds properties={withCoords} />
        {withCoords.map((p) => (
          <Marker key={p.id} position={[p.latitude!, p.longitude!]} icon={goldIcon}>
            <Popup>
              <div className="min-w-[200px]">
                {p.images?.[0] && (
                  <img src={p.images[0]} alt={p.title} className="w-full h-28 object-cover rounded mb-2" />
                )}
                <h3 className="font-semibold text-sm">{p.title}</h3>
                <p className="text-xs text-gray-500">{p.comuna}, {p.region}</p>
                <p className="text-sm font-bold text-gold-dark mt-1">{formatPrice(p.price, p.currency, p.listing_type)}</p>
                <Link
                  to={`/propiedad/${p.id}`}
                  className="inline-block mt-2 text-xs text-white bg-black px-3 py-1 rounded hover:bg-gold hover:text-black transition-colors"
                >
                  Ver detalle
                </Link>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}
