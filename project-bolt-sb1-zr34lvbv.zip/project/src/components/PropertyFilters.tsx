import { useState } from 'react'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import type { PropertyFilters as Filters } from '../types'
import { PROPERTY_TYPES, LISTING_TYPES, REGIONS, COMUNAS_BY_REGION, DORMITORIOS_OPTIONS, BANOS_OPTIONS, ESTACIONAMIENTOS_OPTIONS } from '../data/chile'

interface Props {
  filters: Filters
  onChange: (filters: Filters) => void
  onSearch: () => void
  compact?: boolean
}

export default function PropertyFilters({ filters, onChange, onSearch }: Props) {
  const [showAdvanced, setShowAdvanced] = useState(false)

  const update = (key: keyof Filters, value: string | number) => {
    const next = { ...filters, [key]: value }
    if (key === 'region') next.comuna = ''
    onChange(next)
  }

  const comunas = filters.region ? COMUNAS_BY_REGION[filters.region] || [] : []

  const selectCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 focus:outline-none focus:border-gold/60 transition-colors appearance-none'
  const inputCls = 'w-full bg-[#1c1c1c] border border-gold/20 rounded-lg px-3 py-2.5 text-sm text-neutral-300 focus:outline-none focus:border-gold/60 transition-colors placeholder:text-neutral-600'
  const labelCls = 'block text-[10px] font-medium text-neutral-500 mb-1.5 tracking-wider uppercase'

  const hasActiveFilters = Object.values(filters).some((v) => v !== '' && v !== 0)

  return (
    <div className="w-full">
      {/* Main row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
        <div>
          <label className={labelCls}>Operación</label>
          <select value={filters.listing_type} onChange={(e) => update('listing_type', e.target.value)} className={selectCls}>
            <option value="">Todas</option>
            {LISTING_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className={labelCls}>Inmueble</label>
          <select value={filters.property_type} onChange={(e) => update('property_type', e.target.value)} className={selectCls}>
            <option value="">Todos</option>
            {PROPERTY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className={labelCls}>Región</label>
          <select value={filters.region} onChange={(e) => update('region', e.target.value)} className={selectCls}>
            <option value="">Todas</option>
            {REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div>
          <label className={labelCls}>Comuna</label>
          <select value={filters.comuna} onChange={(e) => update('comuna', e.target.value)} className={selectCls} disabled={!comunas.length}>
            <option value="">Todas</option>
            {comunas.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="col-span-2 sm:col-span-1 flex items-end">
          <button
            onClick={onSearch}
            className="w-full bg-gold hover:bg-gold-light text-black-brand font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 text-sm tracking-wider uppercase"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
          >
            <Search className="w-4 h-4" />
            Buscar
          </button>
        </div>
      </div>

      {/* Advanced toggle */}
      <div className="mt-4 flex items-center gap-4">
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center gap-1.5 text-xs text-neutral-500 hover:text-gold transition-colors tracking-wide uppercase"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          Filtros avanzados
        </button>
        {hasActiveFilters && (
          <button
            onClick={() => onChange({
              listing_type: '', property_type: '', region: '', comuna: '',
              price_min: '', price_max: '', m2_util_min: '', m2_util_max: '',
              m2_terreno_min: '', m2_terreno_max: '', dormitorios: '', banos: '', estacionamientos: '',
            })}
            className="flex items-center gap-1 text-xs text-gold/60 hover:text-gold transition-colors"
          >
            <X className="w-3 h-3" /> Limpiar
          </button>
        )}
      </div>

      {/* Advanced filters */}
      {showAdvanced && (
        <div className="mt-4 pt-4 border-t border-gold/10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 animate-fade-in">
          <div>
            <label className={labelCls}>Precio mín.</label>
            <input type="number" placeholder="0" value={filters.price_min || ''} onChange={(e) => update('price_min', e.target.value ? Number(e.target.value) : '')} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Precio máx.</label>
            <input type="number" placeholder="Sin límite" value={filters.price_max || ''} onChange={(e) => update('price_max', e.target.value ? Number(e.target.value) : '')} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Dormitorios</label>
            <select value={filters.dormitorios || ''} onChange={(e) => update('dormitorios', e.target.value ? Number(e.target.value) : '')} className={selectCls}>
              <option value="">Cualquiera</option>
              {DORMITORIOS_OPTIONS.map((d) => <option key={d} value={d}>{d}+</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls}>Baños</label>
            <select value={filters.banos || ''} onChange={(e) => update('banos', e.target.value ? Number(e.target.value) : '')} className={selectCls}>
              <option value="">Cualquiera</option>
              {BANOS_OPTIONS.map((b) => <option key={b} value={b}>{b}+</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls}>Estacion.</label>
            <select value={filters.estacionamientos || ''} onChange={(e) => update('estacionamientos', e.target.value ? Number(e.target.value) : '')} className={selectCls}>
              <option value="">Cualquiera</option>
              {ESTACIONAMIENTOS_OPTIONS.map((e) => <option key={e} value={e}>{e}+</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls}>m² útil mín.</label>
            <input type="number" placeholder="0" value={filters.m2_util_min || ''} onChange={(e) => update('m2_util_min', e.target.value ? Number(e.target.value) : '')} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>m² útil máx.</label>
            <input type="number" placeholder="Ilimitado" value={filters.m2_util_max || ''} onChange={(e) => update('m2_util_max', e.target.value ? Number(e.target.value) : '')} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>m² terreno mín.</label>
            <input type="number" placeholder="0" value={filters.m2_terreno_min || ''} onChange={(e) => update('m2_terreno_min', e.target.value ? Number(e.target.value) : '')} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>m² terreno máx.</label>
            <input type="number" placeholder="Ilimitado" value={filters.m2_terreno_max || ''} onChange={(e) => update('m2_terreno_max', e.target.value ? Number(e.target.value) : '')} className={inputCls} />
          </div>
        </div>
      )}
    </div>
  )
}
