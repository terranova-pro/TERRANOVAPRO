import { Link } from 'react-router-dom'
import { MapPin, Phone, Mail, ArrowRight } from 'lucide-react'
import { COMPANY_ADDRESS, COMPANY_EMAIL, COMPANY_PHONE } from '../data/chile'

function IgIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
      <circle cx="12" cy="12" r="4"/>
      <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" stroke="none"/>
    </svg>
  )
}

function FbIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
    </svg>
  )
}

export default function Footer() {
  return (
    <footer className="bg-black-brand text-white">
      <div className="border-t border-gold/20">
        <div className="px-[8%] py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16">

            {/* Brand */}
            <div>
              <div className="flex flex-col mb-8">
                <span
                  className="text-white font-bold text-2xl leading-none tracking-wider"
                  style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: '0.1em' }}
                >
                  TERRANOVA
                </span>
                <div className="flex items-center gap-3 mt-1.5">
                  <div className="h-px flex-1 max-w-[32px] bg-gold/50" />
                  <span
                    className="text-gold text-[9px] tracking-[0.35em] uppercase font-medium"
                    style={{ fontFamily: "'Montserrat', sans-serif" }}
                  >
                    PROPIEDADES
                  </span>
                  <div className="h-px flex-1 max-w-[32px] bg-gold/50" />
                </div>
              </div>
              <p className="text-neutral-400 text-base leading-relaxed mb-8">
                Plataforma inmobiliaria premium especializada en el mercado chileno.
                Vendemos, arrendamos y administramos propiedades con excelencia.
              </p>
              <div className="flex gap-3">
                <a
                  href="https://www.facebook.com/share/1Dx7eif9BD/?mibextid=wwXIfr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 border border-gold/25 rounded flex items-center justify-center text-gold hover:bg-gold hover:text-black-brand transition-colors"
                  aria-label="Facebook"
                >
                  <FbIcon />
                </a>
                <a
                  href="https://www.instagram.com/terranova.___?utm_source=qr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 border border-gold/25 rounded flex items-center justify-center text-gold hover:bg-gold hover:text-black-brand transition-colors"
                  aria-label="Instagram"
                >
                  <IgIcon />
                </a>
              </div>
            </div>

            {/* Navigation */}
            <div>
              <h4
                className="text-gold text-xs mb-8 tracking-[0.25em] uppercase font-medium"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                Navegación
              </h4>
              <ul className="space-y-4">
                {[
                  { label: 'Inicio', path: '/' },
                  { label: 'Propiedades', path: '/propiedades' },
                  { label: 'Vende con Terranova', path: '/vende-con-terranova' },
                  { label: 'Vende tu Terreno', path: '/vende-tu-terreno' },
                  { label: 'Inversiones', path: '/inversiones' },
                  { label: 'Blog', path: '/blog' },
                ].map((item) => (
                  <li key={item.path}>
                    <Link
                      to={item.path}
                      className="text-neutral-400 text-sm hover:text-gold transition-colors flex items-center gap-2"
                    >
                      <ArrowRight className="w-3 h-3 text-gold/50" />
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4
                className="text-gold text-xs mb-8 tracking-[0.25em] uppercase font-medium"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                Servicios
              </h4>
              <ul className="space-y-4">
                {[
                  { label: 'Venta de Propiedades', path: '/vende-con-terranova' },
                  { label: 'Venta de Terrenos', path: '/vende-tu-terreno' },
                  { label: 'Arriendo', path: '/propiedades' },
                  { label: 'Administración', path: '/administracion' },
                  { label: 'Asesoría Inversiones', path: '/inversiones' },
                ].map((item) => (
                  <li key={item.path + item.label}>
                    <Link
                      to={item.path}
                      className="text-neutral-400 text-sm hover:text-gold transition-colors flex items-center gap-2"
                    >
                      <ArrowRight className="w-3 h-3 text-gold/50" />
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4
                className="text-gold text-xs mb-8 tracking-[0.25em] uppercase font-medium"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                Contacto
              </h4>
              <ul className="space-y-6">
                <li className="flex items-start gap-3 text-sm text-neutral-400">
                  <MapPin className="w-4 h-4 text-gold mt-0.5 shrink-0" />
                  <span className="leading-relaxed">{COMPANY_ADDRESS}</span>
                </li>
                <li className="flex items-center gap-3 text-sm text-neutral-400">
                  <Phone className="w-4 h-4 text-gold shrink-0" />
                  {COMPANY_PHONE}
                </li>
                <li className="flex items-center gap-3 text-sm text-neutral-400">
                  <Mail className="w-4 h-4 text-gold shrink-0" />
                  {COMPANY_EMAIL}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-gold/10">
        <div className="px-[8%] py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-3">
            <p className="text-neutral-600 text-xs tracking-wide">
              &copy; {new Date().getFullYear()} Terranova Propiedades. Todos los derechos reservados.
            </p>
            <p className="text-neutral-700 text-xs">
              Integración: Portal Inmobiliario · Propiedades Chile · Yapo
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
