import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import ProtectedRoute from './components/intranet/ProtectedRoute'
import Home from './pages/Home'
import Properties from './pages/Properties'
import PropertyDetail from './pages/PropertyDetail'
import SellWithTerranova from './pages/SellWithTerranova'
import SellTerrain from './pages/SellTerrain'
import PropertyManagement from './pages/PropertyManagement'
import Investments from './pages/Investments'
import Blog from './pages/Blog'
import BlogPost from './pages/BlogPost'
import Contact from './pages/Contact'
import About from './pages/About'
import CRM from './pages/CRM'
import Login from './pages/intranet/Login'
import ResetPassword from './pages/intranet/ResetPassword'
import IntranetLayout from './pages/intranet/IntranetLayout'
import Dashboard from './pages/intranet/Dashboard'
import IntranetProperties from './pages/intranet/IntranetProperties'
import Executives from './pages/intranet/Executives'
import IntranetSettings from './pages/intranet/IntranetSettings'

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Home />} />
          <Route path="/propiedades" element={<Properties />} />
          <Route path="/propiedad/:id" element={<PropertyDetail />} />
          <Route path="/vende-con-terranova" element={<SellWithTerranova />} />
          <Route path="/vende-tu-terreno" element={<SellTerrain />} />
          <Route path="/administracion" element={<PropertyManagement />} />
          <Route path="/inversiones" element={<Investments />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/contacto" element={<Contact />} />
          <Route path="/nosotros" element={<About />} />
          <Route path="/crm" element={<CRM />} />

          {/* Intranet */}
          <Route path="/intranet/login" element={<Login />} />
          <Route path="/intranet/restablecer" element={<ResetPassword />} />
          <Route
            path="/intranet"
            element={
              <ProtectedRoute>
                <IntranetLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Navigate to="dashboard" replace />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="propiedades" element={<IntranetProperties />} />
            <Route path="ejecutivos" element={<Executives />} />
            <Route path="configuracion" element={<IntranetSettings />} />
          </Route>
          <Route path="/intranet" element={<Navigate to="/intranet/login" replace />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}
