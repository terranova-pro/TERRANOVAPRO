export const REGIONS = [
  'Arica y Parinacota',
  'Tarapacá',
  'Antofagasta',
  'Atacama',
  'Coquimbo',
  'Valparaíso',
  'Metropolitana',
  'OHiggins',
  'Maule',
  'Biobío',
  'La Araucanía',
  'Los Ríos',
  'Los Lagos',
  'Aysén',
  'Magallanes',
] as const

export const COMUNAS_BY_REGION: Record<string, string[]> = {
  'Metropolitana': ['Santiago Centro', 'Providencia', 'Las Condes', 'Vitacura', 'Lo Barnechea', 'Ñuñoa', 'La Reina', 'Peñalolén', 'La Florida', 'Puente Alto', 'Maipú', 'La Cisterna', 'San Miguel', 'Macul', 'San Joaquín', 'Recoleta', 'Independencia', 'Quilicura', 'Huechuraba', 'Renca', 'Conchalí', 'Cerrillos', 'Estación Central', 'Cerro Navia', 'Lo Prado', 'Pudahuel', 'Pedro Aguirre Cerda', 'El Bosque', 'Colina', 'Lampa', 'San Bernardo', 'Buin'],
  'Valparaíso': ['Valparaíso', 'Viña del Mar', 'Concón', 'Quilpué', 'Villa Alemana', 'San Antonio', 'Los Andes', 'San Felipe', 'Quillota', 'La Cruz', 'Olmué', 'Limache'],
  'Coquimbo': ['La Serena', 'Coquimbo', 'Ovalle', 'Illapel', 'Andacollo', 'Vicuña', 'Paihuano'],
  'Biobío': ['Concepción', 'Talcahuano', 'San Pedro de la Paz', 'Chiguayante', 'Hualpén', 'Los Ángeles', 'Coronel', 'Lota', 'Tomé', 'Penco', 'Chillán'],
  'OHiggins': ['Rancagua', 'Machalí', 'San Fernando', 'Santa Cruz', 'Requínoa', 'Graneros', 'Doñihue'],
  'Los Lagos': ['Puerto Montt', 'Puerto Varas', 'Osorno', 'Valdivia', 'Frutillar', 'Ancud', 'Castro', 'Quellón', 'Chaitén'],
  'Maule': ['Talca', 'Curicó', 'Linares', 'Constitución', 'Parral', 'San Clemente'],
  'La Araucanía': ['Temuco', 'Padre Las Casas', 'Villarrica', 'Pucón', 'Angol', 'Lautaro'],
  'Antofagasta': ['Antofagasta', 'Calama', 'Tocopilla', 'Mejillones', 'Taltal'],
  'Atacama': ['Copiapó', 'Caldera', 'Vallenar', 'Chañaral', 'Diego de Almagro'],
  'Tarapacá': ['Iquique', 'Alto Hospicio', 'Pica', 'Pozo Almonte'],
  'Arica y Parinacota': ['Arica', 'Putre', 'General Lagos'],
  'Los Ríos': ['Valdivia', 'La Unión', 'Río Bueno', 'Futrono', 'Lanco'],
  'Aysén': ['Coyhaique', 'Puerto Aysén', 'Chile Chico', 'Cochamó'],
  'Magallanes': ['Punta Arenas', 'Puerto Natales', 'Porvenir', 'Torres del Paine'],
}

export const PROPERTY_TYPES = [
  { value: 'departamento', label: 'Departamento' },
  { value: 'casa', label: 'Casa' },
  { value: 'terreno', label: 'Terreno' },
  { value: 'oficina', label: 'Oficina' },
  { value: 'comercial', label: 'Local Comercial' },
  { value: 'bodega', label: 'Bodega' },
  { value: 'estacionamiento', label: 'Estacionamiento' },
  { value: 'agricola', label: 'Agrícola' },
] as const

export const LISTING_TYPES = [
  { value: 'venta', label: 'Comprar' },
  { value: 'arriendo', label: 'Arrendar' },
  { value: 'arriendo_diario', label: 'Arriendo Diario' },
  { value: 'arriendo_temporada', label: 'Arriendo Temporada' },
] as const

export const DORMITORIOS_OPTIONS = [1, 2, 3, 4, 5]
export const BANOS_OPTIONS = [1, 2, 3, 4]
export const ESTACIONAMIENTOS_OPTIONS = [0, 1, 2, 3, 4]

export const WHATSAPP_NUMBER = '56926263025'
export const COMPANY_NAME = 'Terranova Propiedades'
export const COMPANY_EMAIL = 'gerencia@parcelaroma.com'
export const COMPANY_PHONE = '+569 2626 3025'
export const COMPANY_ADDRESS = 'Parcela Roma Km 4, Longaví, Maule'
