export interface Property {
  id: string
  title: string
  description: string | null
  property_type: PropertyType
  listing_type: ListingType
  price: number | null
  price_uf: number | null
  currency: 'CLP' | 'UF'
  region: string
  comuna: string
  address: string | null
  latitude: number | null
  longitude: number | null
  m2_util: number | null
  m2_terreno: number | null
  dormitorios: number | null
  banos: number | null
  estacionamientos: number
  year_built: number | null
  featured: boolean
  status: PropertyStatus
  images: string[]
  video_url: string | null
  portal_ids: Record<string, string>
  owner_name: string | null
  owner_phone: string | null
  owner_email: string | null
  created_at: string
  updated_at: string
}

export type PropertyType = 'departamento' | 'casa' | 'terreno' | 'oficina' | 'comercial' | 'bodega' | 'estacionamiento' | 'agricola'
export type ListingType = 'venta' | 'arriendo' | 'arriendo_diario' | 'arriendo_temporada'
export type PropertyStatus = 'disponible' | 'reservada' | 'vendida' | 'arrendada'

export interface Contact {
  id: string
  name: string
  email: string | null
  phone: string | null
  source: 'web' | 'whatsapp' | 'portal' | 'referral' | 'walk_in'
  type: 'buyer' | 'seller' | 'tenant' | 'landlord' | 'investor'
  interest: string | null
  property_id: string | null
  notes: string | null
  status: ContactStatus
  budget_min: number | null
  budget_max: number | null
  preferred_regions: string[]
  created_at: string
  updated_at: string
}

export type ContactStatus = 'nuevo' | 'contactado' | 'calificado' | 'propuesta' | 'negociacion' | 'cerrado' | 'perdido'

export interface PropertySubmission {
  id: string
  owner_name: string
  owner_email: string
  owner_phone: string
  owner_rut: string | null
  property_type: string
  listing_type: string
  address: string
  region: string
  comuna: string
  m2_util: number | null
  m2_terreno: number | null
  dormitorios: number | null
  banos: number | null
  estacionamientos: number
  asking_price: number | null
  description: string | null
  has_title: boolean
  has_plan: boolean
  has_permits: boolean
  status: 'pendiente' | 'en_revision' | 'aprobada' | 'rechazada' | 'publicada'
  is_terreno: boolean
  terrain_type: string | null
  created_at: string
}

export interface BlogPost {
  id: string
  title: string
  slug: string
  excerpt: string | null
  content: string
  image_url: string | null
  category: 'noticias' | 'consejos' | 'mercado' | 'inversiones' | 'legislacion'
  published: boolean
  published_at: string | null
  created_at: string
  updated_at: string
}

export interface ManagementContract {
  id: string
  property_id: string | null
  owner_name: string
  owner_email: string
  owner_phone: string
  monthly_rent: number | null
  commission_pct: number
  start_date: string | null
  end_date: string | null
  status: 'activo' | 'finalizado' | 'suspendido'
  created_at: string
}

export interface PropertyFilters {
  listing_type: ListingType | ''
  property_type: PropertyType | ''
  region: string
  comuna: string
  price_min: number | ''
  price_max: number | ''
  m2_util_min: number | ''
  m2_util_max: number | ''
  m2_terreno_min: number | ''
  m2_terreno_max: number | ''
  dormitorios: number | ''
  banos: number | ''
  estacionamientos: number | ''
}
